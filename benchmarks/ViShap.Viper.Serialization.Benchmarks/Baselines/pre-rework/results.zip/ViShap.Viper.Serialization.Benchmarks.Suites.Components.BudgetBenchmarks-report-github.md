```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                               | Mean      | Error     | StdDev    | Median    | P95       | Op/s            | Allocated |
|------------------------------------- |----------:|----------:|----------:|----------:|----------:|----------------:|----------:|
| &#39;MICRO-02 validate collection count&#39; | 1.2787 ns | 0.0128 ns | 0.0119 ns | 1.2796 ns | 1.2983 ns |   782,065,501.5 |         - |
| &#39;MICRO-02 validate array count&#39;      | 1.2655 ns | 0.0072 ns | 0.0067 ns | 1.2646 ns | 1.2743 ns |   790,188,913.7 |         - |
| &#39;MICRO-02 validate dictionary count&#39; | 1.2624 ns | 0.0115 ns | 0.0107 ns | 1.2679 ns | 1.2718 ns |   792,145,643.5 |         - |
| &#39;MICRO-02 validate rank-3 shape&#39;     | 7.3361 ns | 0.0771 ns | 0.0721 ns | 7.3351 ns | 7.4368 ns |   136,311,359.8 |         - |
| &#39;MICRO-02 charge graph node&#39;         | 0.9202 ns | 0.0108 ns | 0.0101 ns | 0.9186 ns | 0.9345 ns | 1,086,688,348.2 |         - |
| &#39;MICRO-02 charge keyed field&#39;        | 0.9759 ns | 0.0113 ns | 0.0105 ns | 0.9765 ns | 0.9918 ns | 1,024,689,730.9 |         - |
