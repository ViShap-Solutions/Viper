```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                        | Bytes   | Compressible | Mean            | Error         | StdDev        | Median          | P95             | Op/s         | Gen0     | Gen1     | Gen2     | Allocated |
|------------------------------ |-------- |------------- |----------------:|--------------:|--------------:|----------------:|----------------:|-------------:|---------:|---------:|---------:|----------:|
| &#39;MICRO-10 deflate compress&#39;   | 4096    | False        |     67,668.6 ns |     631.32 ns |     590.53 ns |     67,618.4 ns |     68,647.9 ns |    14,777.91 |   0.6104 |        - |        - |    4392 B |
| &#39;MICRO-10 deflate decompress&#39; | 4096    | False        |      1,012.8 ns |      15.38 ns |      14.38 ns |      1,014.8 ns |      1,032.8 ns |   987,390.48 |   0.7076 |   0.0114 |        - |    4440 B |
| &#39;MICRO-10 brotli compress&#39;    | 4096    | False        |     49,743.6 ns |     669.53 ns |     626.28 ns |     49,503.9 ns |     50,978.8 ns |    20,103.10 |        - |        - |        - |         - |
| &#39;MICRO-10 brotli decompress&#39;  | 4096    | False        |        448.3 ns |       4.72 ns |       4.42 ns |        448.0 ns |        455.9 ns | 2,230,731.80 |        - |        - |        - |         - |
| &#39;MICRO-10 deflate compress&#39;   | 4096    | True         |      6,453.9 ns |      86.44 ns |      80.86 ns |      6,427.9 ns |      6,565.1 ns |   154,944.58 |   0.0839 |        - |        - |     544 B |
| &#39;MICRO-10 deflate decompress&#39; | 4096    | True         |      2,467.5 ns |      19.47 ns |      18.21 ns |      2,468.0 ns |      2,490.9 ns |   405,268.80 |   0.0648 |        - |        - |     424 B |
| &#39;MICRO-10 brotli compress&#39;    | 4096    | True         |     14,491.6 ns |     274.59 ns |     256.85 ns |     14,456.1 ns |     14,926.3 ns |    69,005.49 |        - |        - |        - |         - |
| &#39;MICRO-10 brotli decompress&#39;  | 4096    | True         |      4,580.7 ns |      57.17 ns |      50.68 ns |      4,564.7 ns |      4,659.7 ns |   218,306.08 |        - |        - |        - |         - |
| &#39;MICRO-10 deflate compress&#39;   | 65536   | False        |  1,336,764.2 ns |  17,448.79 ns |  16,321.61 ns |  1,333,113.0 ns |  1,365,634.8 ns |       748.08 |  41.0156 |  41.0156 |  41.0156 |  254364 B |
| &#39;MICRO-10 deflate decompress&#39; | 65536   | False        |      8,145.9 ns |      67.89 ns |      63.51 ns |      8,163.6 ns |      8,236.6 ns |   122,760.66 |  10.4065 |        - |        - |   65896 B |
| &#39;MICRO-10 brotli compress&#39;    | 65536   | False        |    130,183.4 ns |   1,128.18 ns |   1,000.10 ns |    130,267.2 ns |    131,510.7 ns |     7,681.47 |        - |        - |        - |         - |
| &#39;MICRO-10 brotli decompress&#39;  | 65536   | False        |      2,782.1 ns |      22.05 ns |      19.55 ns |      2,779.5 ns |      2,812.4 ns |   359,446.46 |        - |        - |        - |         - |
| &#39;MICRO-10 deflate compress&#39;   | 65536   | True         |     17,080.6 ns |     158.67 ns |     140.66 ns |     17,075.4 ns |     17,298.5 ns |    58,545.81 |   0.1221 |        - |        - |     776 B |
| &#39;MICRO-10 deflate decompress&#39; | 65536   | True         |      5,536.7 ns |      58.36 ns |      54.59 ns |      5,518.9 ns |      5,621.6 ns |   180,614.46 |   0.1297 |        - |        - |     824 B |
| &#39;MICRO-10 brotli compress&#39;    | 65536   | True         |     83,645.8 ns |     615.24 ns |     545.40 ns |     83,612.1 ns |     84,453.0 ns |    11,955.17 |        - |        - |        - |         - |
| &#39;MICRO-10 brotli decompress&#39;  | 65536   | True         |     51,334.5 ns |     510.56 ns |     426.34 ns |     51,289.8 ns |     51,900.8 ns |    19,480.07 |        - |        - |        - |         - |
| &#39;MICRO-10 deflate compress&#39;   | 1000000 | False        | 20,806,359.2 ns | 120,323.84 ns | 112,551.00 ns | 20,764,418.8 ns | 20,976,578.1 ns |        48.06 | 281.2500 | 281.2500 | 281.2500 | 2089598 B |
| &#39;MICRO-10 deflate decompress&#39; | 1000000 | False        |    195,469.4 ns |   7,711.41 ns |   7,213.26 ns |    198,594.0 ns |    200,342.5 ns |     5,115.89 | 165.2832 | 165.0391 | 165.0391 | 1001032 B |
| &#39;MICRO-10 brotli compress&#39;    | 1000000 | False        |  1,442,049.1 ns |  12,939.92 ns |  12,104.01 ns |  1,440,495.5 ns |  1,459,589.2 ns |       693.46 |        - |        - |        - |         - |
| &#39;MICRO-10 brotli decompress&#39;  | 1000000 | False        |    245,027.8 ns |   2,523.76 ns |   2,237.24 ns |    244,777.7 ns |    248,859.8 ns |     4,081.17 |        - |        - |        - |         - |
| &#39;MICRO-10 deflate compress&#39;   | 1000000 | True         |    229,418.8 ns |   2,732.21 ns |   2,422.03 ns |    229,247.2 ns |    232,447.4 ns |     4,358.84 |   0.9766 |        - |        - |    6656 B |
| &#39;MICRO-10 deflate decompress&#39; | 1000000 | True         |     39,305.2 ns |     411.78 ns |     385.17 ns |     39,292.8 ns |     39,785.8 ns |    25,441.91 |   1.0376 |        - |        - |    6704 B |
| &#39;MICRO-10 brotli compress&#39;    | 1000000 | True         |  1,049,097.1 ns |  15,452.91 ns |  14,454.66 ns |  1,053,080.5 ns |  1,067,636.1 ns |       953.20 |        - |        - |        - |         - |
| &#39;MICRO-10 brotli decompress&#39;  | 1000000 | True         |    926,798.5 ns |  12,649.37 ns |  11,832.23 ns |    923,261.8 ns |    945,606.2 ns |     1,078.98 |        - |        - |        - |         - |
