```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                       | Mean     | Error     | StdDev    | Median   | P95       | Op/s          | Allocated |
|----------------------------- |---------:|----------:|----------:|---------:|----------:|--------------:|----------:|
| &#39;MICRO-04 positional lookup&#39; | 4.312 ns | 0.0728 ns | 0.0681 ns | 4.313 ns |  4.409 ns | 231,886,987.1 |         - |
| &#39;MICRO-04 keyed lookup&#39;      | 4.288 ns | 0.0744 ns | 0.0696 ns | 4.283 ns |  4.390 ns | 233,216,314.8 |         - |
| &#39;MICRO-04 union lookup&#39;      | 9.936 ns | 0.1219 ns | 0.1081 ns | 9.935 ns | 10.097 ns | 100,643,559.8 |         - |
