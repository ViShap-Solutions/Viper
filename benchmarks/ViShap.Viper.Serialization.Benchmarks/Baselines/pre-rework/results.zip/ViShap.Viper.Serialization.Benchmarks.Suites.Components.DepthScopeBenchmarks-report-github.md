```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                        | Depth | Mean           | Error         | StdDev        | Median         | P95            | Op/s          | Gen0   | Allocated |
|------------------------------ |------ |---------------:|--------------:|--------------:|---------------:|---------------:|--------------:|-------:|----------:|
| &#39;MICRO-03 enter and exit&#39;     | 1     |       2.004 ns |     0.0253 ns |     0.0236 ns |       2.000 ns |       2.036 ns | 499,055,089.3 |      - |         - |
| &#39;MICRO-03 descend and return&#39; | 1     |       6.671 ns |     0.2538 ns |     0.2374 ns |       6.605 ns |       7.022 ns | 149,901,536.0 |      - |         - |
| &#39;MICRO-03 descend and unwind&#39; | 1     |   1,944.871 ns |    29.1793 ns |    27.2943 ns |   1,949.752 ns |   1,989.766 ns |     514,172.9 | 0.0496 |     320 B |
| &#39;MICRO-03 enter and exit&#39;     | 8     |       1.995 ns |     0.0283 ns |     0.0265 ns |       2.001 ns |       2.031 ns | 501,249,931.6 |      - |         - |
| &#39;MICRO-03 descend and return&#39; | 8     |      26.129 ns |     0.3992 ns |     0.3734 ns |      26.155 ns |      26.658 ns |  38,271,048.9 |      - |         - |
| &#39;MICRO-03 descend and unwind&#39; | 8     |   3,663.335 ns |    29.0156 ns |    25.7215 ns |   3,665.978 ns |   3,697.142 ns |     272,975.3 | 0.1221 |     784 B |
| &#39;MICRO-03 enter and exit&#39;     | 64    |       1.995 ns |     0.0339 ns |     0.0317 ns |       1.998 ns |       2.040 ns | 501,281,504.9 |      - |         - |
| &#39;MICRO-03 descend and return&#39; | 64    |     237.284 ns |     2.5451 ns |     2.1253 ns |     237.137 ns |     240.262 ns |   4,214,363.5 |      - |         - |
| &#39;MICRO-03 descend and unwind&#39; | 64    |  17,550.845 ns |   178.8784 ns |   149.3715 ns |  17,561.996 ns |  17,746.410 ns |      56,977.3 | 0.7019 |    4488 B |
| &#39;MICRO-03 enter and exit&#39;     | 500   |       2.037 ns |     0.0334 ns |     0.0312 ns |       2.050 ns |       2.084 ns | 490,835,168.4 |      - |         - |
| &#39;MICRO-03 descend and return&#39; | 500   |   1,702.976 ns |    24.4663 ns |    22.8858 ns |   1,700.160 ns |   1,732.896 ns |     587,207.4 |      - |         - |
| &#39;MICRO-03 descend and unwind&#39; | 500   | 126,025.890 ns | 2,032.4749 ns | 1,901.1783 ns | 126,366.064 ns | 128,319.858 ns |       7,934.9 | 2.6855 |   16856 B |
