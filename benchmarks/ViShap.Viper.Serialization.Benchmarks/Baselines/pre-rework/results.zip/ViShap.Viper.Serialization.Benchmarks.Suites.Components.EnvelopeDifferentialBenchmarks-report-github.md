```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                | Configuration        | Mean      | Error     | StdDev    | Median    | P95       | Op/s      | Gen0   | Gen1   | Allocated |
|---------------------- |--------------------- |----------:|----------:|----------:|----------:|----------:|----------:|-------:|-------:|----------:|
| &#39;DIFF-01 serialize&#39;   | Headerless           |  9.501 μs | 0.1862 μs | 0.1742 μs |  9.453 μs |  9.797 μs | 105,255.9 | 1.6022 | 0.0153 |   9.91 KB |
| &#39;DIFF-01 deserialize&#39; | Headerless           | 14.062 μs | 0.2078 μs | 0.1735 μs | 14.050 μs | 14.318 μs |  71,114.6 | 2.2583 | 0.0305 |  13.91 KB |
| &#39;DIFF-01 serialize&#39;   | MinimalHeader        |  8.959 μs | 0.1213 μs | 0.1134 μs |  8.966 μs |  9.122 μs | 111,617.5 | 2.0752 | 0.0153 |  12.74 KB |
| &#39;DIFF-01 deserialize&#39; | MinimalHeader        | 11.329 μs | 0.2848 μs | 0.2224 μs | 11.302 μs | 11.658 μs |  88,266.3 | 2.5024 | 0.0305 |  15.36 KB |
| &#39;DIFF-01 serialize&#39;   | Encrypted            | 11.161 μs | 0.4728 μs | 0.4423 μs | 11.080 μs | 11.940 μs |  89,595.1 | 2.2736 | 0.0153 |  13.97 KB |
| &#39;DIFF-01 deserialize&#39; | Encrypted            | 13.458 μs | 1.0300 μs | 0.9635 μs | 13.256 μs | 15.049 μs |  74,303.5 | 2.6855 |      - |  16.55 KB |
| &#39;DIFF-01 serialize&#39;   | EncryptedWithKeyId   | 10.790 μs | 0.1357 μs | 0.1269 μs | 10.795 μs | 10.964 μs |  92,679.8 | 2.2888 | 0.0153 |  14.09 KB |
| &#39;DIFF-01 deserialize&#39; | EncryptedWithKeyId   | 13.088 μs | 0.2068 μs | 0.1935 μs | 13.092 μs | 13.426 μs |  76,403.2 | 2.7313 | 0.0458 |  16.82 KB |
| &#39;DIFF-01 serialize&#39;   | Protected            | 36.694 μs | 0.5099 μs | 0.4520 μs | 36.665 μs | 37.340 μs |  27,252.6 | 2.5635 |      - |   15.9 KB |
| &#39;DIFF-01 deserialize&#39; | Protected            | 20.389 μs | 0.2356 μs | 0.2204 μs | 20.369 μs | 20.703 μs |  49,045.1 | 3.0823 | 0.0305 |  18.94 KB |
| &#39;DIFF-01 serialize&#39;   | ProtectedCustomNames | 37.743 μs | 0.2547 μs | 0.2258 μs | 37.799 μs | 38.004 μs |  26,495.3 | 2.6855 |      - |  16.47 KB |
| &#39;DIFF-01 deserialize&#39; | ProtectedCustomNames | 21.187 μs | 0.3468 μs | 0.3244 μs | 21.139 μs | 21.668 μs |  47,199.0 | 3.2959 | 0.0305 |  20.21 KB |
