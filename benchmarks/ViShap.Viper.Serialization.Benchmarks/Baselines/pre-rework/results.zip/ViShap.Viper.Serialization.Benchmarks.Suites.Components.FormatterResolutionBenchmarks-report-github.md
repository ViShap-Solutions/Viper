```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                              | Mean     | Error     | StdDev    | Median   | P95      | Op/s          | Allocated |
|------------------------------------ |---------:|----------:|----------:|---------:|---------:|--------------:|----------:|
| &#39;MICRO-05 resolve claimed sequence&#39; | 4.260 ns | 0.0595 ns | 0.0557 ns | 4.280 ns | 4.331 ns | 234,743,790.8 |         - |
| &#39;MICRO-05 resolve claimed map&#39;      | 4.243 ns | 0.0739 ns | 0.0691 ns | 4.242 ns | 4.351 ns | 235,707,134.9 |         - |
| &#39;MICRO-05 resolve member-encoded&#39;   | 4.215 ns | 0.0709 ns | 0.0663 ns | 4.219 ns | 4.311 ns | 237,220,915.9 |         - |
