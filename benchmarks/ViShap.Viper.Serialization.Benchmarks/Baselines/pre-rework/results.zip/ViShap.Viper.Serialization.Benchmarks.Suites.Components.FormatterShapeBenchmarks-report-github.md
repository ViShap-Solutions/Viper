```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                     | Mean          | Error       | StdDev      | Median        | P95           | Op/s          | Gen0   | Gen1   | Allocated |
|--------------------------- |--------------:|------------:|------------:|--------------:|--------------:|--------------:|-------:|-------:|----------:|
| &#39;MICRO-06 scalar write&#39;    |      9.029 ns |   0.1415 ns |   0.1324 ns |      9.044 ns |      9.204 ns | 110,753,845.3 | 0.0051 |      - |      32 B |
| &#39;MICRO-06 scalar read&#39;     |     14.813 ns |   0.8717 ns |   0.7727 ns |     14.518 ns |     16.124 ns |  67,508,777.7 | 0.0051 |      - |      32 B |
| &#39;MICRO-06 sequence write&#39;  |  2,244.716 ns |  36.1283 ns |  33.7944 ns |  2,245.527 ns |  2,296.631 ns |     445,490.7 | 0.4005 |      - |    2520 B |
| &#39;MICRO-06 sequence read&#39;   |  2,801.057 ns |  36.1631 ns |  33.8270 ns |  2,799.738 ns |  2,853.968 ns |     357,008.0 | 0.4768 |      - |    3008 B |
| &#39;MICRO-06 map write&#39;       |  5,849.508 ns |  69.8264 ns |  61.8993 ns |  5,852.554 ns |  5,935.748 ns |     170,954.5 | 1.2970 |      - |    8160 B |
| &#39;MICRO-06 map read&#39;        | 16,621.858 ns | 317.0668 ns | 296.5845 ns | 16,684.702 ns | 17,064.143 ns |      60,161.7 | 3.0518 | 0.0610 |   19232 B |
| &#39;MICRO-06 composite write&#39; |    129.698 ns |   1.5699 ns |   1.3917 ns |    130.049 ns |    131.038 ns |   7,710,227.7 | 0.0138 |      - |      88 B |
| &#39;MICRO-06 composite read&#39;  |    165.459 ns |   2.6684 ns |   2.3654 ns |    165.133 ns |    169.731 ns |   6,043,801.2 | 0.0484 |      - |     304 B |
