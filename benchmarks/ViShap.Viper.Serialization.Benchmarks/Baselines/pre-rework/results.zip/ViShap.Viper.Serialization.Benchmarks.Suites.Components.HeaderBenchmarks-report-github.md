```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                           | AllFields | Mean      | Error    | StdDev   | Median    | P95       | Op/s         | Gen0   | Allocated |
|--------------------------------- |---------- |----------:|---------:|---------:|----------:|----------:|-------------:|-------:|----------:|
| &#39;MICRO-08 write header&#39;          | False     |  90.71 ns | 2.125 ns | 1.987 ns |  90.23 ns |  93.76 ns | 11,024,343.0 |      - |         - |
| &#39;MICRO-08 parse header&#39;          | False     | 121.65 ns | 1.568 ns | 1.467 ns | 121.67 ns | 123.53 ns |  8,220,528.8 | 0.0114 |      72 B |
| &#39;MICRO-08 build associated data&#39; | False     |  84.19 ns | 2.115 ns | 1.766 ns |  84.72 ns |  86.07 ns | 11,877,268.7 | 0.0381 |     240 B |
| &#39;MICRO-08 write header&#39;          | True      | 232.32 ns | 4.081 ns | 3.817 ns | 231.54 ns | 237.45 ns |  4,304,366.9 | 0.0305 |     192 B |
| &#39;MICRO-08 parse header&#39;          | True      | 404.70 ns | 5.302 ns | 4.959 ns | 406.36 ns | 411.24 ns |  2,470,973.1 | 0.2089 |    1312 B |
| &#39;MICRO-08 build associated data&#39; | True      | 125.01 ns | 1.824 ns | 1.616 ns | 124.88 ns | 127.66 ns |  7,999,293.1 | 0.0968 |     608 B |
