```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                         | Bytes   | Mean         | Error       | StdDev      | Median       | P95          | Op/s        | Gen0   | Allocated |
|------------------------------- |-------- |-------------:|------------:|------------:|-------------:|-------------:|------------:|-------:|----------:|
| &#39;MICRO-10 crc32 compute&#39;       | 4096    |     119.6 ns |     1.68 ns |     1.58 ns |     119.7 ns |     122.0 ns | 8,363,679.7 |      - |         - |
| &#39;MICRO-10 aes-256-gcm encrypt&#39; | 4096    |   1,262.9 ns |    11.45 ns |    10.15 ns |   1,265.8 ns |   1,276.5 ns |   791,837.2 | 0.0114 |      72 B |
| &#39;MICRO-10 aes-256-gcm decrypt&#39; | 4096    |   1,232.3 ns |    17.70 ns |    16.56 ns |   1,234.8 ns |   1,253.9 ns |   811,461.1 | 0.0057 |      40 B |
| &#39;MICRO-10 crc32 compute&#39;       | 65536   |   1,883.8 ns |    10.90 ns |     9.10 ns |   1,882.1 ns |   1,899.0 ns |   530,837.5 |      - |         - |
| &#39;MICRO-10 aes-256-gcm encrypt&#39; | 65536   |   8,112.4 ns |    82.41 ns |    73.05 ns |   8,130.3 ns |   8,190.6 ns |   123,268.2 |      - |      72 B |
| &#39;MICRO-10 aes-256-gcm decrypt&#39; | 65536   |   9,546.8 ns |   151.95 ns |   142.14 ns |   9,555.4 ns |   9,759.8 ns |   104,747.1 |      - |      40 B |
| &#39;MICRO-10 crc32 compute&#39;       | 1000000 |  28,778.4 ns |   420.78 ns |   393.60 ns |  28,588.1 ns |  29,353.4 ns |    34,748.2 |      - |         - |
| &#39;MICRO-10 aes-256-gcm encrypt&#39; | 1000000 | 115,766.9 ns | 1,310.75 ns | 1,161.94 ns | 116,011.5 ns | 117,597.3 ns |     8,638.0 |      - |      40 B |
| &#39;MICRO-10 aes-256-gcm decrypt&#39; | 1000000 | 123,565.7 ns | 3,080.45 ns | 2,572.31 ns | 123,570.0 ns | 127,336.3 ns |     8,092.9 |      - |      40 B |
