```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                               | SharedPercent | Mean       | Error     | StdDev    | Median     | P95        | Op/s             | Gen0   | Gen1   | Allocated |
|------------------------------------- |-------------- |-----------:|----------:|----------:|-----------:|-----------:|-----------------:|-------:|-------:|----------:|
| &#39;MICRO-07 write lookup and register&#39; | 0             | 21.7929 ns | 0.2104 ns | 0.1968 ns | 21.7901 ns | 22.1108 ns |     45,886,467.1 | 0.0162 | 0.0032 |     102 B |
| &#39;MICRO-07 read register and resolve&#39; | 0             | 19.1749 ns | 0.2930 ns | 0.2741 ns | 19.1618 ns | 19.5390 ns |     52,151,549.0 | 0.0162 | 0.0032 |     102 B |
| &#39;MICRO-07 table construction&#39;        | 0             |  0.0149 ns | 0.0002 ns | 0.0002 ns |  0.0149 ns |  0.0150 ns | 67,183,038,553.4 | 0.0000 |      - |         - |
| &#39;MICRO-07 write lookup and register&#39; | 10            | 16.5973 ns | 0.3290 ns | 0.3077 ns | 16.5449 ns | 17.1060 ns |     60,250,791.7 | 0.0077 | 0.0008 |      48 B |
| &#39;MICRO-07 read register and resolve&#39; | 10            | 14.1742 ns | 0.2249 ns | 0.2104 ns | 14.1745 ns | 14.4861 ns |     70,550,535.0 | 0.0077 | 0.0008 |      48 B |
| &#39;MICRO-07 table construction&#39;        | 10            |  0.0149 ns | 0.0003 ns | 0.0003 ns |  0.0149 ns |  0.0154 ns | 66,986,788,170.4 | 0.0000 |      - |         - |
| &#39;MICRO-07 write lookup and register&#39; | 50            | 12.1392 ns | 0.1163 ns | 0.1031 ns | 12.1508 ns | 12.3110 ns |     82,377,566.2 | 0.0077 | 0.0009 |      48 B |
| &#39;MICRO-07 read register and resolve&#39; | 50            | 10.2987 ns | 0.1131 ns | 0.1058 ns | 10.2774 ns | 10.4408 ns |     97,099,314.1 | 0.0077 | 0.0009 |      48 B |
| &#39;MICRO-07 table construction&#39;        | 50            |  0.0149 ns | 0.0002 ns | 0.0002 ns |  0.0150 ns |  0.0152 ns | 66,913,897,931.5 | 0.0000 |      - |         - |
| &#39;MICRO-07 write lookup and register&#39; | 90            |  7.3654 ns | 0.0795 ns | 0.0705 ns |  7.3748 ns |  7.4646 ns |    135,770,230.9 | 0.0016 | 0.0000 |      10 B |
| &#39;MICRO-07 read register and resolve&#39; | 90            |  4.7971 ns | 0.0642 ns | 0.0601 ns |  4.7939 ns |  4.8766 ns |    208,459,955.3 | 0.0016 | 0.0000 |      10 B |
| &#39;MICRO-07 table construction&#39;        | 90            |  0.0154 ns | 0.0003 ns | 0.0003 ns |  0.0154 ns |  0.0158 ns | 64,910,063,420.2 | 0.0000 |      - |         - |
