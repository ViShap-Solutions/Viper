```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                                | Mean     | Error     | StdDev    | Median   | P95      | Op/s          | Gen0   | Allocated |
|-------------------------------------- |---------:|----------:|----------:|---------:|---------:|--------------:|-------:|----------:|
| &#39;MICRO-07 write scope enter and exit&#39; | 8.166 ns | 0.2384 ns | 0.2113 ns | 8.167 ns | 8.500 ns | 122,452,430.0 | 0.0127 |      80 B |
| &#39;MICRO-07 read scope enter and exit&#39;  | 7.518 ns | 0.1654 ns | 0.1547 ns | 7.525 ns | 7.782 ns | 133,009,686.9 | 0.0127 |      80 B |
