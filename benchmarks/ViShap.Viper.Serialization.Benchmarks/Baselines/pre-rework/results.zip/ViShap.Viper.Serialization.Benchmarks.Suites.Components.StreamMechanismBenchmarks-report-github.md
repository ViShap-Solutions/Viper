```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                         | Mean      | Error     | StdDev    | Median    | P95       | Op/s             | Gen0   | Allocated |
|------------------------------- |----------:|----------:|----------:|----------:|----------:|-----------------:|-------:|----------:|
| &#39;MICRO-09 bare write&#39;          | 5.8138 ns | 0.0540 ns | 0.0451 ns | 5.8268 ns | 5.8589 ns |    172,003,800.8 |      - |         - |
| &#39;MICRO-09 metered write&#39;       | 9.5060 ns | 0.1202 ns | 0.1124 ns | 9.5141 ns | 9.7004 ns |    105,196,401.4 |      - |         - |
| &#39;MICRO-09 bare read&#39;           | 4.9089 ns | 0.0588 ns | 0.0550 ns | 4.9114 ns | 4.9712 ns |    203,710,141.2 |      - |         - |
| &#39;MICRO-09 metered read&#39;        | 7.7650 ns | 0.1093 ns | 0.1022 ns | 7.7904 ns | 7.9441 ns |    128,782,343.8 |      - |         - |
| &#39;MICRO-09 window read&#39;         | 7.7924 ns | 0.0833 ns | 0.0739 ns | 7.8078 ns | 7.8915 ns |    128,329,722.0 | 0.0000 |         - |
| &#39;MICRO-09 window construction&#39; | 0.0200 ns | 0.0004 ns | 0.0004 ns | 0.0201 ns | 0.0205 ns | 49,988,575,527.4 | 0.0000 |         - |
