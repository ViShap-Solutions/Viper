```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method           | Primitive       | Mean      | Error     | StdDev    | Median    | P95       | Op/s          | Gen0   | Allocated |
|----------------- |---------------- |----------:|----------:|----------:|----------:|----------:|--------------:|-------:|----------:|
| &#39;MICRO-01 write&#39; | Byte            |  4.450 ns | 0.0720 ns | 0.0601 ns |  4.455 ns |  4.541 ns | 224,736,259.0 |      - |         - |
| &#39;MICRO-01 read&#39;  | Byte            |  2.559 ns | 0.0360 ns | 0.0319 ns |  2.555 ns |  2.612 ns | 390,814,077.6 |      - |         - |
| &#39;MICRO-01 write&#39; | Int16           |  5.886 ns | 0.0897 ns | 0.0840 ns |  5.883 ns |  6.002 ns | 169,903,559.3 |      - |         - |
| &#39;MICRO-01 read&#39;  | Int16           | 11.139 ns | 0.1336 ns | 0.1116 ns | 11.093 ns | 11.317 ns |  89,775,406.8 |      - |         - |
| &#39;MICRO-01 write&#39; | Int32           |  5.739 ns | 0.1151 ns | 0.0961 ns |  5.718 ns |  5.884 ns | 174,234,076.2 |      - |         - |
| &#39;MICRO-01 read&#39;  | Int32           | 11.375 ns | 0.1474 ns | 0.1306 ns | 11.394 ns | 11.579 ns |  87,908,754.9 |      - |         - |
| &#39;MICRO-01 write&#39; | Int64           |  5.609 ns | 0.1258 ns | 0.1115 ns |  5.622 ns |  5.778 ns | 178,281,389.5 |      - |         - |
| &#39;MICRO-01 read&#39;  | Int64           | 11.000 ns | 0.1366 ns | 0.1211 ns | 11.047 ns | 11.153 ns |  90,905,283.6 |      - |         - |
| &#39;MICRO-01 write&#39; | Double          |  6.474 ns | 0.1121 ns | 0.1049 ns |  6.471 ns |  6.631 ns | 154,456,063.1 |      - |         - |
| &#39;MICRO-01 read&#39;  | Double          | 11.450 ns | 0.1245 ns | 0.1165 ns | 11.443 ns | 11.611 ns |  87,339,313.4 |      - |         - |
| &#39;MICRO-01 write&#39; | Decimal         |  7.643 ns | 0.0912 ns | 0.0853 ns |  7.661 ns |  7.739 ns | 130,841,679.4 |      - |         - |
| &#39;MICRO-01 read&#39;  | Decimal         | 35.589 ns | 0.5446 ns | 0.4828 ns | 35.477 ns | 36.448 ns |  28,098,572.1 |      - |         - |
| &#39;MICRO-01 write&#39; | VarIntOneByte   |  4.411 ns | 0.0935 ns | 0.0829 ns |  4.386 ns |  4.533 ns | 226,695,817.9 |      - |         - |
| &#39;MICRO-01 read&#39;  | VarIntOneByte   | 10.661 ns | 0.2854 ns | 0.2383 ns | 10.672 ns | 11.038 ns |  93,799,997.9 | 0.0115 |      72 B |
| &#39;MICRO-01 write&#39; | VarIntFiveBytes | 22.605 ns | 0.3814 ns | 0.3567 ns | 22.717 ns | 23.057 ns |  44,237,193.4 |      - |         - |
| &#39;MICRO-01 read&#39;  | VarIntFiveBytes | 43.822 ns | 0.6952 ns | 0.6503 ns | 43.836 ns | 44.821 ns |  22,819,683.3 | 0.0574 |     360 B |
