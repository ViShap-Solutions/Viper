```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                         | Threads | Data                 | Mean         | Error       | StdDev      | Median       | P95          | Op/s      | Gen0       | Gen1       | Gen2     | Allocated    |
|------------------------------- |-------- |--------------------- |-------------:|------------:|------------:|-------------:|-------------:|----------:|-----------:|-----------:|---------:|-------------:|
| &#39;PAR serialize on N threads&#39;   | 1       | DATA-01 TinyFlat     |     281.2 μs |     0.94 μs |     0.88 μs |     280.9 μs |     282.7 μs | 3,556.149 |    70.3125 |     0.4883 |        - |    431.99 KB |
| &#39;PAR deserialize on N threads&#39; | 1       | DATA-01 TinyFlat     |     304.4 μs |     1.13 μs |     1.00 μs |     304.5 μs |     305.7 μs | 3,285.221 |    48.3398 |          - |        - |    291.39 KB |
| &#39;PAR serialize on N threads&#39;   | 1       | DATA-02 MediumObject |   1,815.8 μs |    22.61 μs |    18.88 μs |   1,818.4 μs |   1,839.0 μs |   550.722 |   406.2500 |          - |        - |   2547.89 KB |
| &#39;PAR deserialize on N threads&#39; | 1       | DATA-02 MediumObject |   2,317.9 μs |    24.71 μs |    23.11 μs |   2,321.1 μs |   2,346.6 μs |   431.420 |   500.0000 |          - |        - |    3072.1 KB |
| &#39;PAR serialize on N threads&#39;   | 1       | DATA-(...)Small [24] |  23,964.4 μs |   507.22 μs |   474.46 μs |  23,829.1 μs |  24,662.1 μs |    41.729 |  7125.0000 |  1156.2500 |        - |  43749.18 KB |
| &#39;PAR deserialize on N threads&#39; | 1       | DATA-(...)Small [24] |  26,066.0 μs |   548.21 μs |   485.98 μs |  26,018.3 μs |  26,824.7 μs |    38.364 |  5375.0000 |   843.7500 |        - |  32976.17 KB |
| &#39;PAR serialize on N threads&#39;   | 2       | DATA-01 TinyFlat     |     371.4 μs |     7.15 μs |     6.69 μs |     373.0 μs |     380.3 μs | 2,692.220 |   143.5547 |     1.4648 |        - |    863.69 KB |
| &#39;PAR deserialize on N threads&#39; | 2       | DATA-01 TinyFlat     |     399.8 μs |     4.14 μs |     3.87 μs |     398.5 μs |     406.7 μs | 2,501.140 |    96.6797 |     0.9766 |        - |    582.49 KB |
| &#39;PAR serialize on N threads&#39;   | 2       | DATA-02 MediumObject |   2,274.0 μs |    77.48 μs |    72.47 μs |   2,276.4 μs |   2,379.0 μs |   439.761 |   859.3750 |    15.6250 |        - |   5095.51 KB |
| &#39;PAR deserialize on N threads&#39; | 2       | DATA-02 MediumObject |   2,745.2 μs |    92.96 μs |    86.95 μs |   2,713.2 μs |   2,876.1 μs |   364.270 |  1031.2500 |    15.6250 |        - |   6143.97 KB |
| &#39;PAR serialize on N threads&#39;   | 2       | DATA-(...)Small [24] |  27,857.9 μs |   476.98 μs |   446.17 μs |  27,855.2 μs |  28,407.4 μs |    35.896 | 15062.5000 |  3375.0000 |        - |  87498.06 KB |
| &#39;PAR deserialize on N threads&#39; | 2       | DATA-(...)Small [24] |  29,304.6 μs |   401.77 μs |   335.50 μs |  29,297.9 μs |  29,743.0 μs |    34.124 | 10812.5000 |  2593.7500 |        - |  65952.12 KB |
| &#39;PAR serialize on N threads&#39;   | 4       | DATA-01 TinyFlat     |     583.1 μs |    13.29 μs |    11.78 μs |     582.1 μs |     601.8 μs | 1,715.071 |   285.1563 |     3.9063 |        - |   1727.08 KB |
| &#39;PAR deserialize on N threads&#39; | 4       | DATA-01 TinyFlat     |     578.2 μs |    14.07 μs |    12.47 μs |     578.8 μs |     595.5 μs | 1,729.410 |   191.4063 |          - |        - |    1164.7 KB |
| &#39;PAR serialize on N threads&#39;   | 4       | DATA-02 MediumObject |   2,877.3 μs |   242.45 μs |   226.79 μs |   2,812.6 μs |   3,306.0 μs |   347.552 |  1718.7500 |    93.7500 |        - |  10190.86 KB |
| &#39;PAR deserialize on N threads&#39; | 4       | DATA-02 MediumObject |   3,657.4 μs |   297.24 μs |   248.21 μs |   3,607.1 μs |   4,116.0 μs |   273.415 |  2062.5000 |    93.7500 |        - |  12288.67 KB |
| &#39;PAR serialize on N threads&#39;   | 4       | DATA-(...)Small [24] |  36,378.8 μs |   916.15 μs |   765.03 μs |  36,542.3 μs |  37,448.6 μs |    27.489 | 31000.0000 |  9333.3333 |        - | 174995.83 KB |
| &#39;PAR deserialize on N threads&#39; | 4       | DATA-(...)Small [24] |  39,849.9 μs | 1,095.62 μs | 1,024.85 μs |  39,687.7 μs |  41,037.6 μs |    25.094 | 21583.3333 |  1583.3333 |        - | 131904.22 KB |
| &#39;PAR serialize on N threads&#39;   | 8       | DATA-01 TinyFlat     |   1,105.5 μs |    50.77 μs |    47.49 μs |   1,107.1 μs |   1,168.3 μs |   904.568 |   574.2188 |     9.7656 |        - |   3453.86 KB |
| &#39;PAR deserialize on N threads&#39; | 8       | DATA-01 TinyFlat     |   1,071.8 μs |    71.95 μs |    67.30 μs |   1,041.6 μs |   1,183.3 μs |   932.992 |   382.8125 |          - |        - |   2329.18 KB |
| &#39;PAR serialize on N threads&#39;   | 8       | DATA-02 MediumObject |   5,056.5 μs |   131.08 μs |   122.61 μs |   5,050.9 μs |   5,215.2 μs |   197.764 |  3492.1875 |   320.3125 |        - |  20381.44 KB |
| &#39;PAR deserialize on N threads&#39; | 8       | DATA-02 MediumObject |   6,172.2 μs |   225.19 μs |   199.62 μs |   6,106.7 μs |   6,529.4 μs |   162.017 |  4156.2500 |   375.0000 |        - |  24576.39 KB |
| &#39;PAR serialize on N threads&#39;   | 8       | DATA-(...)Small [24] |  60,178.8 μs | 1,385.26 μs | 1,295.77 μs |  59,941.6 μs |  61,923.5 μs |    16.617 | 63500.0000 | 21000.0000 |        - | 349991.36 KB |
| &#39;PAR deserialize on N threads&#39; | 8       | DATA-(...)Small [24] |  67,313.0 μs |   682.16 μs |   604.71 μs |  67,339.2 μs |  68,138.0 μs |    14.856 | 43250.0000 | 20125.0000 |        - | 263810.06 KB |
| &#39;PAR serialize on N threads&#39;   | 12      | DATA-01 TinyFlat     |   1,443.1 μs |    50.76 μs |    47.49 μs |   1,420.9 μs |   1,521.1 μs |   692.950 |   859.3750 |    15.6250 |        - |   5180.64 KB |
| &#39;PAR deserialize on N threads&#39; | 12      | DATA-01 TinyFlat     |   1,459.1 μs |    43.66 μs |    38.70 μs |   1,456.9 μs |   1,529.0 μs |   685.367 |   578.1250 |     7.8125 |        - |   3493.68 KB |
| &#39;PAR serialize on N threads&#39;   | 12      | DATA-02 MediumObject |   7,725.4 μs |   241.74 μs |   226.13 μs |   7,757.8 μs |   8,046.6 μs |   129.443 |  5218.7500 |   625.0000 |        - |  30572.16 KB |
| &#39;PAR deserialize on N threads&#39; | 12      | DATA-02 MediumObject |   9,543.5 μs |   241.84 μs |   226.22 μs |   9,558.7 μs |   9,818.0 μs |   104.783 |  6250.0000 |   812.5000 |        - |  36866.37 KB |
| &#39;PAR serialize on N threads&#39;   | 12      | DATA-(...)Small [24] | 102,436.3 μs |   893.74 μs |   836.00 μs | 102,137.6 μs | 103,788.1 μs |     9.762 | 96200.0000 | 32600.0000 |        - | 524986.89 KB |
| &#39;PAR deserialize on N threads&#39; | 12      | DATA-(...)Small [24] | 112,050.1 μs | 1,859.97 μs | 1,739.82 μs | 111,670.1 μs | 114,582.5 μs |     8.925 | 64800.0000 | 57600.0000 | 400.0000 | 395719.13 KB |
