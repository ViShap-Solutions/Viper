```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                 | Depth | Mean         | Error       | StdDev      | Median       | P95          | Op/s        | Gen0    | Gen1   | Allocated |
|----------------------- |------ |-------------:|------------:|------------:|-------------:|-------------:|------------:|--------:|-------:|----------:|
| &#39;SCALE-03 serialize&#39;   | 1     |     674.7 ns |     6.02 ns |     5.34 ns |     674.9 ns |     680.3 ns | 1,482,139.0 |  0.2842 |      - |   1.74 KB |
| &#39;SCALE-03 deserialize&#39; | 1     |     742.6 ns |     5.72 ns |     5.35 ns |     743.2 ns |     749.8 ns | 1,346,706.2 |  0.1726 |      - |   1.06 KB |
| &#39;SCALE-03 serialize&#39;   | 5     |   1,423.4 ns |    13.70 ns |    12.82 ns |   1,427.7 ns |   1,437.5 ns |   702,539.2 |  0.3986 |      - |   2.45 KB |
| &#39;SCALE-03 deserialize&#39; | 5     |   1,585.1 ns |    15.45 ns |    14.45 ns |   1,584.8 ns |   1,604.5 ns |   630,860.6 |  0.3567 |      - |    2.2 KB |
| &#39;SCALE-03 serialize&#39;   | 25    |   5,471.5 ns |    80.55 ns |    75.35 ns |   5,479.4 ns |   5,581.8 ns |   182,764.2 |  1.3351 | 0.0076 |    8.2 KB |
| &#39;SCALE-03 deserialize&#39; | 25    |   5,614.0 ns |    96.60 ns |    90.36 ns |   5,626.9 ns |   5,726.8 ns |   178,127.5 |  1.2436 | 0.0076 |   7.62 KB |
| &#39;SCALE-03 serialize&#39;   | 100   |  21,644.2 ns |   176.90 ns |   165.48 ns |  21,642.5 ns |  21,869.3 ns |    46,201.8 |  5.0049 | 0.1221 |  30.68 KB |
| &#39;SCALE-03 deserialize&#39; | 100   |  21,378.2 ns |   258.70 ns |   241.99 ns |  21,422.3 ns |  21,663.5 ns |    46,776.7 |  4.5471 | 0.1526 |  27.95 KB |
| &#39;SCALE-03 serialize&#39;   | 500   | 128,267.1 ns | 8,196.35 ns | 6,844.32 ns | 130,678.4 ns | 131,602.8 ns |     7,796.2 | 22.7051 | 2.6855 | 139.15 KB |
| &#39;SCALE-03 deserialize&#39; | 500   | 116,285.1 ns | 1,071.90 ns | 1,002.66 ns | 116,254.6 ns | 117,766.2 ns |     8,599.6 | 22.3389 | 3.4180 | 137.09 KB |
