```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method              | Data                 | Mean     | Error     | StdDev    | Median   | P95      | Op/s          | Allocated |
|-------------------- |--------------------- |---------:|----------:|----------:|---------:|---------:|--------------:|----------:|
| &#39;floor serialize&#39;   | DATA-01 TinyFlat     | 4.265 ns | 0.0969 ns | 0.0906 ns | 4.242 ns | 4.400 ns | 234,451,143.8 |         - |
| &#39;floor deserialize&#39; | DATA-01 TinyFlat     | 4.320 ns | 0.0719 ns | 0.0637 ns | 4.310 ns | 4.415 ns | 231,501,644.0 |         - |
| &#39;floor serialize&#39;   | DATA-02 MediumObject | 4.929 ns | 0.1589 ns | 0.1409 ns | 4.929 ns | 5.174 ns | 202,900,922.0 |         - |
| &#39;floor deserialize&#39; | DATA-02 MediumObject | 4.348 ns | 0.1025 ns | 0.0959 ns | 4.328 ns | 4.511 ns | 229,977,517.7 |         - |
| &#39;floor serialize&#39;   | DATA-(...)Small [24] | 3.844 ns | 0.0911 ns | 0.0852 ns | 3.837 ns | 3.963 ns | 260,153,561.0 |         - |
| &#39;floor deserialize&#39; | DATA-(...)Small [24] | 4.205 ns | 0.0912 ns | 0.0808 ns | 4.194 ns | 4.348 ns | 237,827,507.6 |         - |
| &#39;floor serialize&#39;   | DATA-(...)Large [24] | 4.314 ns | 0.1056 ns | 0.0988 ns | 4.289 ns | 4.487 ns | 231,782,355.4 |         - |
| &#39;floor deserialize&#39; | DATA-(...)Large [24] | 4.207 ns | 0.0181 ns | 0.0161 ns | 4.212 ns | 4.229 ns | 237,672,842.1 |         - |
| &#39;floor serialize&#39;   | DATA-(...)Heavy [23] | 3.867 ns | 0.0704 ns | 0.0659 ns | 3.844 ns | 3.964 ns | 258,580,295.5 |         - |
| &#39;floor deserialize&#39; | DATA-(...)Heavy [23] | 4.278 ns | 0.1062 ns | 0.0993 ns | 4.278 ns | 4.409 ns | 233,737,156.4 |         - |
| &#39;floor serialize&#39;   | DATA-(...)Heavy [28] | 4.062 ns | 0.1477 ns | 0.1310 ns | 4.097 ns | 4.210 ns | 246,193,175.7 |         - |
| &#39;floor deserialize&#39; | DATA-(...)Heavy [28] | 4.449 ns | 0.0600 ns | 0.0501 ns | 4.438 ns | 4.527 ns | 224,787,693.0 |         - |
