```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                 | Members | Keyed | Mean        | Error     | StdDev    | Median      | P95         | Op/s        | Gen0    | Gen1   | Allocated |
|----------------------- |-------- |------ |------------:|----------:|----------:|------------:|------------:|------------:|--------:|-------:|----------:|
| &#39;SCALE-04 serialize&#39;   | 5       | False |    753.4 ns |  23.58 ns |  19.69 ns |    743.5 ns |    789.4 ns | 1,327,394.4 |  0.3052 |      - |   1.88 KB |
| &#39;SCALE-04 deserialize&#39; | 5       | False |    850.3 ns |  20.06 ns |  18.76 ns |    845.8 ns |    878.4 ns | 1,175,994.9 |  0.1955 |      - |    1.2 KB |
| &#39;SCALE-04 serialize&#39;   | 5       | True  |  1,060.4 ns |  20.80 ns |  18.44 ns |  1,059.3 ns |  1,090.8 ns |   943,017.4 |  0.3910 |      - |    2.4 KB |
| &#39;SCALE-04 deserialize&#39; | 5       | True  |  1,752.5 ns |  18.36 ns |  15.33 ns |  1,752.8 ns |  1,776.5 ns |   570,627.1 |  0.5016 |      - |   3.08 KB |
| &#39;SCALE-04 serialize&#39;   | 20      | False |  1,229.0 ns |  18.75 ns |  17.54 ns |  1,226.1 ns |  1,255.6 ns |   813,666.9 |  0.4101 |      - |   2.52 KB |
| &#39;SCALE-04 deserialize&#39; | 20      | False |  1,366.6 ns |  26.50 ns |  24.78 ns |  1,363.4 ns |  1,399.5 ns |   731,734.2 |  0.3395 |      - |   2.09 KB |
| &#39;SCALE-04 serialize&#39;   | 20      | True  |  2,628.0 ns |  82.35 ns |  77.03 ns |  2,606.4 ns |  2,755.2 ns |   380,519.6 |  0.9193 | 0.0038 |   5.63 KB |
| &#39;SCALE-04 deserialize&#39; | 20      | True  |  4,864.4 ns |  48.36 ns |  42.87 ns |  4,864.6 ns |  4,927.6 ns |   205,576.3 |  1.5411 |      - |   9.48 KB |
| &#39;SCALE-04 serialize&#39;   | 50      | False |  2,373.3 ns |  45.46 ns |  40.29 ns |  2,376.9 ns |  2,437.8 ns |   421,355.8 |  0.8087 | 0.0038 |   4.96 KB |
| &#39;SCALE-04 deserialize&#39; | 50      | False |  2,503.5 ns |  40.89 ns |  36.25 ns |  2,509.4 ns |  2,545.7 ns |   399,445.7 |  0.6523 |      - |      4 KB |
| &#39;SCALE-04 serialize&#39;   | 50      | True  |  5,795.8 ns | 107.59 ns | 100.64 ns |  5,818.6 ns |  5,968.4 ns |   172,540.2 |  1.8616 | 0.0153 |  11.41 KB |
| &#39;SCALE-04 deserialize&#39; | 50      | True  | 11,535.8 ns | 133.94 ns | 125.28 ns | 11,550.5 ns | 11,705.0 ns |    86,686.4 |  3.6774 | 0.0153 |  22.55 KB |
| &#39;SCALE-04 serialize&#39;   | 100     | False |  4,575.7 ns |  44.51 ns |  41.64 ns |  4,587.5 ns |  4,621.0 ns |   218,546.7 |  1.4343 | 0.0076 |    8.8 KB |
| &#39;SCALE-04 deserialize&#39; | 100     | False |  5,059.1 ns |  92.09 ns |  81.63 ns |  5,049.8 ns |  5,198.1 ns |   197,662.7 |  1.1673 | 0.0076 |   7.16 KB |
| &#39;SCALE-04 serialize&#39;   | 100     | True  | 10,946.4 ns | 181.85 ns | 170.10 ns | 10,943.2 ns | 11,215.2 ns |    91,354.6 |  3.5248 | 0.0458 |  21.66 KB |
| &#39;SCALE-04 deserialize&#39; | 100     | True  | 22,161.0 ns | 310.86 ns | 275.57 ns | 22,231.8 ns | 22,512.1 ns |    45,124.4 |  7.2327 | 0.0916 |  44.32 KB |
| &#39;SCALE-04 serialize&#39;   | 200     | False | 11,175.9 ns | 136.35 ns | 127.55 ns | 11,194.4 ns | 11,355.5 ns |    89,478.4 |  2.6855 | 0.0305 |   16.5 KB |
| &#39;SCALE-04 deserialize&#39; | 200     | False | 11,835.4 ns | 137.72 ns | 128.83 ns | 11,809.2 ns | 12,014.0 ns |    84,492.5 |  2.1820 | 0.0305 |  13.46 KB |
| &#39;SCALE-04 serialize&#39;   | 200     | True  | 22,436.3 ns | 329.22 ns | 274.91 ns | 22,343.6 ns | 22,819.2 ns |    44,570.6 |  6.8970 | 0.1831 |  42.43 KB |
| &#39;SCALE-04 deserialize&#39; | 200     | True  | 45,828.5 ns | 589.42 ns | 522.50 ns | 45,879.4 ns | 46,534.4 ns |    21,820.5 | 15.3198 | 0.3662 |  93.91 KB |
