```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.400
  [Host]      : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.11 (10.0.11, 10.0.1126.37416), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                 | SharedPercent | Profile            | Mean       | Error    | StdDev   | Median     | P95        | Op/s    | Gen0     | Gen1    | Gen2    | Allocated  |
|----------------------- |-------------- |------------------- |-----------:|---------:|---------:|-----------:|-----------:|--------:|---------:|--------:|--------:|-----------:|
| &#39;SCALE-07 serialize&#39;   | 0             | Default            |   774.2 μs |  6.92 μs |  6.14 μs |   775.4 μs |   782.1 μs | 1,291.7 |  88.8672 | 17.5781 |       - |   549.1 KB |
| &#39;SCALE-07 deserialize&#39; | 0             | Default            | 1,260.2 μs | 13.03 μs | 10.88 μs | 1,261.8 μs | 1,273.1 μs |   793.5 | 167.9688 | 64.4531 |       - | 1040.25 KB |
| &#39;SCALE-07 serialize&#39;   | 0             | PreserveReferences |   986.3 μs | 14.10 μs | 12.50 μs |   987.5 μs | 1,002.6 μs | 1,013.9 | 140.6250 | 70.3125 | 70.3125 |  946.27 KB |
| &#39;SCALE-07 deserialize&#39; | 0             | PreserveReferences | 2,069.9 μs | 28.58 μs | 26.74 μs | 2,064.9 μs | 2,109.8 μs |   483.1 | 195.3125 | 78.1250 | 35.1563 | 1270.49 KB |
| &#39;SCALE-07 serialize&#39;   | 10            | Default            |   753.2 μs |  3.70 μs |  3.46 μs |   753.8 μs |   756.7 μs | 1,327.6 |  87.8906 | 20.5078 |       - |  544.87 KB |
| &#39;SCALE-07 deserialize&#39; | 10            | Default            | 1,260.4 μs | 24.71 μs | 23.11 μs | 1,253.6 μs | 1,296.8 μs |   793.4 | 167.9688 | 60.5469 |       - | 1036.83 KB |
| &#39;SCALE-07 serialize&#39;   | 10            | PreserveReferences |   944.5 μs | 11.62 μs | 10.30 μs |   943.4 μs |   959.3 μs | 1,058.8 | 142.5781 | 71.2891 | 71.2891 |   902.6 KB |
| &#39;SCALE-07 deserialize&#39; | 10            | PreserveReferences | 1,861.1 μs | 43.43 μs | 40.63 μs | 1,875.9 μs | 1,902.9 μs |   537.3 | 171.8750 | 78.1250 | 23.4375 | 1169.01 KB |
| &#39;SCALE-07 serialize&#39;   | 50            | Default            |   761.8 μs | 15.61 μs | 14.60 μs |   758.9 μs |   784.9 μs | 1,312.7 |  84.9609 | 18.5547 |       - |   525.4 KB |
| &#39;SCALE-07 deserialize&#39; | 50            | Default            | 1,245.1 μs | 30.49 μs | 28.52 μs | 1,243.9 μs | 1,283.5 μs |   803.1 | 166.0156 | 54.6875 |       - | 1019.73 KB |
| &#39;SCALE-07 serialize&#39;   | 50            | PreserveReferences |   560.7 μs | 10.48 μs |  9.80 μs |   561.2 μs |   571.9 μs | 1,783.6 |  90.8203 | 30.2734 | 30.2734 |  599.43 KB |
| &#39;SCALE-07 deserialize&#39; | 50            | PreserveReferences | 1,125.4 μs | 16.67 μs | 15.59 μs | 1,125.8 μs | 1,151.0 μs |   888.6 | 119.1406 | 44.9219 | 29.2969 |  765.06 KB |
| &#39;SCALE-07 serialize&#39;   | 90            | Default            |   712.1 μs |  9.12 μs |  8.53 μs |   715.8 μs |   721.5 μs | 1,404.3 |  82.0313 | 13.6719 |       - |  505.37 KB |
| &#39;SCALE-07 deserialize&#39; | 90            | Default            | 1,222.2 μs | 17.77 μs | 16.63 μs | 1,221.2 μs | 1,246.7 μs |   818.2 | 162.1094 | 56.6406 |       - | 1002.04 KB |
| &#39;SCALE-07 serialize&#39;   | 90            | PreserveReferences |   177.1 μs |  3.31 μs |  3.09 μs |   176.8 μs |   182.1 μs | 5,645.4 |  26.8555 |  4.3945 |       - |  166.38 KB |
| &#39;SCALE-07 deserialize&#39; | 90            | PreserveReferences |   227.8 μs |  2.80 μs |  2.48 μs |   226.9 μs |   232.0 μs | 4,390.4 |  26.1230 |  5.1270 |       - |  160.39 KB |
