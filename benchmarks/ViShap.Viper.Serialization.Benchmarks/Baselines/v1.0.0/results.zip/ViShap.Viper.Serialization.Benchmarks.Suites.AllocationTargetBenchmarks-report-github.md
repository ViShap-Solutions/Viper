```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                                                         | Mean          | Error         | StdDev        | Median        | P95           | Op/s          | Gen0   | Gen1   | Allocated |
|--------------------------------------------------------------- |--------------:|--------------:|--------------:|--------------:|--------------:|--------------:|-------:|-------:|----------:|
| &#39;ALLOC-10 write V1 → IBufferWriter&#39;                            |    342.470 ns |    12.5652 ns |    11.7535 ns |    343.656 ns |    357.901 ns |   2,919,962.0 | 0.0429 |      - |     272 B |
| &#39;ALLOC-11 write V0 → IBufferWriter&#39;                            |    229.894 ns |     7.1966 ns |     6.7317 ns |    228.767 ns |    238.380 ns |   4,349,836.7 | 0.0215 |      - |     136 B |
| &#39;ALLOC-12 write Brotli → IBufferWriter&#39;                        | 11,885.347 ns |   219.5464 ns |   194.6222 ns | 11,923.956 ns | 12,129.369 ns |      84,137.2 | 0.0458 |      - |     352 B |
| &#39;ALLOC-13 write Deflate → IBufferWriter&#39;                       |  5,699.913 ns |   192.5105 ns |   170.6555 ns |  5,614.280 ns |  5,956.432 ns |     175,441.3 | 0.0839 |      - |     552 B |
| &#39;ALLOC-14 write AES-256-GCM → IBufferWriter&#39;                   |  1,318.717 ns |    37.0792 ns |    34.6839 ns |  1,323.006 ns |  1,374.903 ns |     758,313.1 | 0.0687 |      - |     432 B |
| &#39;ALLOC-15 Serialize → byte[]&#39;                                  |    343.904 ns |    12.7406 ns |    11.9175 ns |    346.119 ns |    361.911 ns |   2,907,784.2 | 0.0587 |      - |     368 B |
| &#39;ALLOC-15 reference: the array alone&#39;                          |      4.832 ns |     0.1803 ns |     0.1686 ns |      4.880 ns |      5.048 ns | 206,939,048.0 | 0.0153 |      - |      96 B |
| &#39;ALLOC-16 SerializePooled&#39;                                     |    341.836 ns |    10.1525 ns |     9.4967 ns |    340.663 ns |    353.602 ns |   2,925,377.0 | 0.0482 |      - |     304 B |
| &#39;ALLOC-17 read record of primitives ← span&#39;                    |    220.617 ns |     7.2821 ns |     6.8117 ns |    222.959 ns |    228.121 ns |   4,532,736.9 | 0.0241 |      - |     152 B |
| &#39;ALLOC-17 reference: the record alone&#39;                         |      9.620 ns |     0.3424 ns |     0.3203 ns |      9.672 ns |      9.968 ns | 103,945,333.5 | 0.0127 |      - |      80 B |
| &#39;ALLOC-18 read graph ← span&#39;                                   | 28,416.578 ns |   761.8758 ns |   712.6591 ns | 28,406.070 ns | 29,678.075 ns |      35,190.7 | 3.6011 | 0.2441 |   22656 B |
| &#39;ALLOC-18 write graph → IBufferWriter&#39;                         | 21,465.942 ns |   757.0283 ns |   708.1247 ns | 21,133.835 ns | 22,374.708 ns |      46,585.4 | 0.0305 |      - |     368 B |
| &#39;ALLOC-18 reference: the graph alone&#39;                          |  3,211.740 ns |    63.0376 ns |    58.9654 ns |  3,211.094 ns |  3,300.226 ns |     311,357.7 | 3.5973 | 0.2556 |   22584 B |
| &#39;ALLOC-19 read graph with PreserveReferences ← span&#39;           | 32,161.511 ns | 1,214.1339 ns | 1,135.7016 ns | 32,307.465 ns | 33,673.489 ns |      31,093.1 | 3.6011 | 0.2441 |   22656 B |
| &#39;ALLOC-19 write graph with PreserveReferences → IBufferWriter&#39; | 27,471.298 ns | 1,016.0618 ns |   950.4249 ns | 26,986.600 ns | 28,759.029 ns |      36,401.6 | 0.0305 |      - |     368 B |
| &#39;ALLOC-20 SerializeAsync → Stream&#39;                             | 21,654.514 ns |   654.6824 ns |   612.3903 ns | 21,440.659 ns | 22,669.447 ns |      46,179.7 | 0.0305 |      - |     368 B |
| &#39;ALLOC-20 reference: Serialize → Stream&#39;                       | 21,220.028 ns |   757.0769 ns |   708.1702 ns | 21,333.688 ns | 22,095.708 ns |      47,125.3 | 0.0305 |      - |     368 B |
| &#39;ALLOC-20 DeserializeAsync ← Stream&#39;                           | 30,307.422 ns |   660.1328 ns |   617.4887 ns | 30,155.951 ns | 31,358.707 ns |      32,995.2 | 3.6011 | 0.2441 |   22656 B |
| &#39;ALLOC-20 reference: Deserialize ← Stream&#39;                     | 28,253.722 ns |   450.0860 ns |   421.0107 ns | 28,213.617 ns | 28,968.002 ns |      35,393.6 | 3.6011 | 0.2441 |   22656 B |
