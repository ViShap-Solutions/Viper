```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                                  | Length  | Mean            | Error         | StdDev        | Median          | P95             | Op/s         | Gen0     | Gen1     | Gen2     | Allocated |
|---------------------------------------- |-------- |----------------:|--------------:|--------------:|----------------:|----------------:|-------------:|---------:|---------:|---------:|----------:|
| &#39;MICRO-18 read into the final array&#39;    | 16      |        63.72 ns |      2.243 ns |      2.098 ns |        63.56 ns |        66.52 ns | 15,693,060.3 |   0.0139 |        - |        - |      88 B |
| &#39;MICRO-18 read through the pooled path&#39; | 16      |        79.04 ns |      2.803 ns |      2.622 ns |        77.57 ns |        82.44 ns | 12,651,325.2 |   0.0139 |        - |        - |      88 B |
| &#39;MICRO-18 read into the final array&#39;    | 4096    |    10,831.40 ns |    240.910 ns |    225.347 ns |    10,767.48 ns |    11,232.26 ns |     92,324.2 |   2.6093 |        - |        - |   16408 B |
| &#39;MICRO-18 read through the pooled path&#39; | 4096    |    13,763.14 ns |    352.981 ns |    330.178 ns |    13,852.02 ns |    14,264.23 ns |     72,657.9 |   2.6093 |        - |        - |   16408 B |
| &#39;MICRO-18 read into the final array&#39;    | 1000000 | 2,945,071.21 ns | 12,846.619 ns | 11,388.193 ns | 2,944,949.22 ns | 2,962,071.46 ns |        339.6 | 277.3438 | 277.3438 | 277.3438 | 4000297 B |
| &#39;MICRO-18 read through the pooled path&#39; | 1000000 | 3,737,925.55 ns | 42,650.293 ns | 39,895.111 ns | 3,726,064.45 ns | 3,811,179.77 ns |        267.5 | 191.4063 | 191.4063 | 191.4063 | 4000212 B |
