```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                               | Mean      | Error     | StdDev    | Median    | P95       | Op/s            | Allocated |
|------------------------------------- |----------:|----------:|----------:|----------:|----------:|----------------:|----------:|
| &#39;MICRO-02 validate collection count&#39; | 1.2461 ns | 0.0331 ns | 0.0310 ns | 1.2469 ns | 1.2855 ns |   802,486,873.4 |         - |
| &#39;MICRO-02 validate array count&#39;      | 1.6458 ns | 0.0446 ns | 0.0417 ns | 1.6191 ns | 1.7059 ns |   607,603,072.0 |         - |
| &#39;MICRO-02 validate dictionary count&#39; | 1.2064 ns | 0.0250 ns | 0.0234 ns | 1.1994 ns | 1.2384 ns |   828,890,690.6 |         - |
| &#39;MICRO-02 validate rank-3 shape&#39;     | 7.1068 ns | 0.1699 ns | 0.1589 ns | 7.0272 ns | 7.3356 ns |   140,709,340.3 |         - |
| &#39;MICRO-02 charge graph node&#39;         | 1.2372 ns | 0.0214 ns | 0.0201 ns | 1.2387 ns | 1.2663 ns |   808,254,724.0 |         - |
| &#39;MICRO-02 charge keyed field&#39;        | 0.9433 ns | 0.0296 ns | 0.0277 ns | 0.9419 ns | 0.9819 ns | 1,060,071,628.8 |         - |
