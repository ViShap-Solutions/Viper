```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                        | Bytes   | Compressible | Mean            | Error         | StdDev        | Median          | P95             | Op/s         | Gen0   | Allocated |
|------------------------------ |-------- |------------- |----------------:|--------------:|--------------:|----------------:|----------------:|-------------:|-------:|----------:|
| &#39;MICRO-10 deflate compress&#39;   | 4096    | False        |     64,380.7 ns |   1,064.94 ns |     944.04 ns |     64,204.4 ns |     66,071.7 ns |    15,532.60 |      - |     232 B |
| &#39;MICRO-10 deflate decompress&#39; | 4096    | False        |        846.6 ns |      24.94 ns |      23.32 ns |        835.9 ns |        890.1 ns | 1,181,126.66 | 0.0458 |     288 B |
| &#39;MICRO-10 brotli compress&#39;    | 4096    | False        |     47,305.3 ns |     682.72 ns |     638.61 ns |     47,132.3 ns |     48,291.7 ns |    21,139.27 |      - |      32 B |
| &#39;MICRO-10 brotli decompress&#39;  | 4096    | False        |        488.9 ns |      11.09 ns |      10.37 ns |        491.6 ns |        503.7 ns | 2,045,576.05 | 0.0048 |      32 B |
| &#39;MICRO-10 deflate compress&#39;   | 4096    | True         |      6,077.3 ns |     109.98 ns |     102.87 ns |      6,082.0 ns |      6,223.6 ns |   164,546.91 | 0.0305 |     232 B |
| &#39;MICRO-10 deflate decompress&#39; | 4096    | True         |      2,468.2 ns |      46.56 ns |      43.56 ns |      2,470.1 ns |      2,535.8 ns |   405,145.92 | 0.0458 |     288 B |
| &#39;MICRO-10 brotli compress&#39;    | 4096    | True         |     13,648.1 ns |     179.58 ns |     167.98 ns |     13,630.3 ns |     13,892.5 ns |    73,270.37 |      - |      32 B |
| &#39;MICRO-10 brotli decompress&#39;  | 4096    | True         |      4,485.1 ns |     108.68 ns |     101.66 ns |      4,498.0 ns |      4,647.9 ns |   222,962.64 |      - |      32 B |
| &#39;MICRO-10 deflate compress&#39;   | 65536   | False        |  1,223,155.2 ns |  23,324.48 ns |  21,817.73 ns |  1,228,442.4 ns |  1,253,565.5 ns |       817.56 |      - |     232 B |
| &#39;MICRO-10 deflate decompress&#39; | 65536   | False        |      6,839.3 ns |     164.95 ns |     154.29 ns |      6,783.2 ns |      7,083.8 ns |   146,214.56 | 0.0458 |     288 B |
| &#39;MICRO-10 brotli compress&#39;    | 65536   | False        |    127,181.1 ns |   2,033.67 ns |   1,802.79 ns |    126,884.9 ns |    130,058.1 ns |     7,862.81 |      - |      32 B |
| &#39;MICRO-10 brotli decompress&#39;  | 65536   | False        |      3,069.2 ns |      83.75 ns |      78.34 ns |      3,082.5 ns |      3,163.9 ns |   325,818.91 | 0.0038 |      32 B |
| &#39;MICRO-10 deflate compress&#39;   | 65536   | True         |     16,339.7 ns |     373.83 ns |     349.68 ns |     16,207.9 ns |     16,882.1 ns |    61,200.63 | 0.0305 |     232 B |
| &#39;MICRO-10 deflate decompress&#39; | 65536   | True         |      5,859.5 ns |     129.84 ns |     121.46 ns |      5,890.0 ns |      6,026.9 ns |   170,663.38 | 0.0458 |     288 B |
| &#39;MICRO-10 brotli compress&#39;    | 65536   | True         |     86,640.8 ns |   1,134.15 ns |   1,060.89 ns |     86,503.3 ns |     88,265.5 ns |    11,541.90 |      - |      32 B |
| &#39;MICRO-10 brotli decompress&#39;  | 65536   | True         |     52,657.9 ns |   1,561.96 ns |   1,461.06 ns |     52,135.3 ns |     55,246.7 ns |    18,990.51 |      - |      32 B |
| &#39;MICRO-10 deflate compress&#39;   | 1000000 | False        | 20,503,523.0 ns | 493,188.47 ns | 461,328.80 ns | 20,520,979.7 ns | 21,139,229.1 ns |        48.77 |      - |     232 B |
| &#39;MICRO-10 deflate decompress&#39; | 1000000 | False        |    123,619.8 ns |   3,666.09 ns |   3,429.26 ns |    124,186.2 ns |    127,404.3 ns |     8,089.32 |      - |     288 B |
| &#39;MICRO-10 brotli compress&#39;    | 1000000 | False        |  1,338,279.3 ns |  25,484.18 ns |  23,837.91 ns |  1,330,007.8 ns |  1,381,558.1 ns |       747.23 |      - |      32 B |
| &#39;MICRO-10 brotli decompress&#39;  | 1000000 | False        |    254,594.7 ns |   2,801.49 ns |   2,620.52 ns |    254,722.7 ns |    258,569.2 ns |     3,927.81 |      - |      32 B |
| &#39;MICRO-10 deflate compress&#39;   | 1000000 | True         |    219,050.6 ns |   6,031.66 ns |   5,642.02 ns |    219,372.1 ns |    226,200.6 ns |     4,565.16 |      - |     232 B |
| &#39;MICRO-10 deflate decompress&#39; | 1000000 | True         |     56,414.5 ns |   1,190.51 ns |   1,113.60 ns |     55,931.7 ns |     58,483.7 ns |    17,725.95 |      - |     288 B |
| &#39;MICRO-10 brotli compress&#39;    | 1000000 | True         |  1,022,613.2 ns |  18,935.16 ns |  17,711.96 ns |  1,013,361.9 ns |  1,055,602.5 ns |       977.89 |      - |      32 B |
| &#39;MICRO-10 brotli decompress&#39;  | 1000000 | True         |    912,574.0 ns |  17,320.08 ns |  16,201.21 ns |    904,671.0 ns |    935,864.3 ns |     1,095.80 |      - |      32 B |
