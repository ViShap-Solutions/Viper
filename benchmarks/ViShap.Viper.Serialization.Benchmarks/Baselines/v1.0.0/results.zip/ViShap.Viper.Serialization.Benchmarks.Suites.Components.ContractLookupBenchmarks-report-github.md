```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                       | Mean     | Error     | StdDev    | Median   | P95      | Op/s          | Allocated |
|----------------------------- |---------:|----------:|----------:|---------:|---------:|--------------:|----------:|
| &#39;MICRO-04 positional lookup&#39; | 4.160 ns | 0.1367 ns | 0.1279 ns | 4.093 ns | 4.362 ns | 240,408,036.3 |         - |
| &#39;MICRO-04 keyed lookup&#39;      | 4.164 ns | 0.1537 ns | 0.1438 ns | 4.184 ns | 4.371 ns | 240,128,664.6 |         - |
| &#39;MICRO-04 union lookup&#39;      | 9.418 ns | 0.3049 ns | 0.2852 ns | 9.437 ns | 9.776 ns | 106,180,288.1 |         - |
