```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                                   | Depth | Mean          | Error        | StdDev       | Median        | P95           | Op/s         | Gen0   | Gen1   | Allocated |
|----------------------------------------- |------ |--------------:|-------------:|-------------:|--------------:|--------------:|-------------:|-------:|-------:|----------:|
| &#39;ALLOC-09 engine write, ancestor stack&#39;  | 4     |     392.52 ns |    12.123 ns |    11.340 ns |     389.42 ns |     409.74 ns |  2,547,646.0 | 0.0215 |      - |     136 B |
| &#39;ALLOC-09 per-operation HashSet replica&#39; | 4     |      79.48 ns |     2.346 ns |     2.194 ns |      78.30 ns |      82.71 ns | 12,581,935.1 | 0.0587 |      - |     368 B |
| &#39;ALLOC-09 engine write, ancestor stack&#39;  | 32    |   3,216.77 ns |    95.175 ns |    89.027 ns |   3,168.07 ns |   3,345.99 ns |    310,870.6 | 0.0343 |      - |     232 B |
| &#39;ALLOC-09 per-operation HashSet replica&#39; | 32    |     489.01 ns |    12.496 ns |    11.689 ns |     490.87 ns |     505.11 ns |  2,044,952.6 | 0.2365 |      - |    1488 B |
| &#39;ALLOC-09 engine write, ancestor stack&#39;  | 500   | 101,203.95 ns | 2,281.711 ns | 2,134.314 ns | 100,597.27 ns | 104,414.41 ns |      9,881.0 |      - |      - |     232 B |
| &#39;ALLOC-09 per-operation HashSet replica&#39; | 500   |   7,729.24 ns |   116.811 ns |   109.265 ns |   7,700.65 ns |   7,906.94 ns |    129,378.9 | 5.4779 | 0.1068 |   34416 B |
