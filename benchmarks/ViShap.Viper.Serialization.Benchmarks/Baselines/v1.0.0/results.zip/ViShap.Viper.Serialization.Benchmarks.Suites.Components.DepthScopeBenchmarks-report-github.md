```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                        | Depth | Mean            | Error         | StdDev        | Median          | P95             | Op/s            | Gen0   | Allocated |
|------------------------------ |------ |----------------:|--------------:|--------------:|----------------:|----------------:|----------------:|-------:|----------:|
| &#39;MICRO-03 enter and exit&#39;     | 1     |       1.0708 ns |     0.0238 ns |     0.0222 ns |       1.0705 ns |       1.1062 ns |   933,841,450.3 |      - |         - |
| &#39;MICRO-03 descend and return&#39; | 1     |       3.6621 ns |     0.1495 ns |     0.1398 ns |       3.6674 ns |       3.8546 ns |   273,066,844.4 |      - |         - |
| &#39;MICRO-03 descend and unwind&#39; | 1     |   1,897.9868 ns |    47.9215 ns |    44.8258 ns |   1,891.9907 ns |   1,962.2233 ns |       526,874.1 | 0.0496 |     320 B |
| &#39;MICRO-03 enter and exit&#39;     | 8     |       0.9618 ns |     0.0230 ns |     0.0215 ns |       0.9672 ns |       0.9932 ns | 1,039,701,729.9 |      - |         - |
| &#39;MICRO-03 descend and return&#39; | 8     |      21.2904 ns |     0.8956 ns |     0.8378 ns |      21.1951 ns |      22.5516 ns |    46,969,559.4 |      - |         - |
| &#39;MICRO-03 descend and unwind&#39; | 8     |   3,520.7999 ns |    98.6336 ns |    92.2619 ns |   3,499.1848 ns |   3,661.0160 ns |       284,026.4 | 0.1221 |     784 B |
| &#39;MICRO-03 enter and exit&#39;     | 64    |       1.0511 ns |     0.0183 ns |     0.0171 ns |       1.0479 ns |       1.0806 ns |   951,367,754.5 |      - |         - |
| &#39;MICRO-03 descend and return&#39; | 64    |     218.4134 ns |     4.8216 ns |     4.5101 ns |     215.6010 ns |     225.5614 ns |     4,578,473.1 |      - |         - |
| &#39;MICRO-03 descend and unwind&#39; | 64    |  16,279.7050 ns |   427.1852 ns |   399.5893 ns |  16,386.2152 ns |  16,742.1649 ns |        61,426.2 | 0.7019 |    4488 B |
| &#39;MICRO-03 enter and exit&#39;     | 500   |       0.9544 ns |     0.0250 ns |     0.0234 ns |       0.9403 ns |       0.9882 ns | 1,047,804,885.5 |      - |         - |
| &#39;MICRO-03 descend and return&#39; | 500   |   1,447.3136 ns |    20.6795 ns |    19.3436 ns |   1,434.9895 ns |   1,485.8944 ns |       690,935.2 |      - |         - |
| &#39;MICRO-03 descend and unwind&#39; | 500   | 112,437.1922 ns | 2,157.9168 ns | 1,912.9370 ns | 112,097.5769 ns | 115,740.0934 ns |         8,893.9 | 2.6855 |   16856 B |
