```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                | Configuration        | Mean      | Error     | StdDev    | Median    | P95       | Op/s      | Gen0   | Gen1   | Allocated |
|---------------------- |--------------------- |----------:|----------:|----------:|----------:|----------:|----------:|-------:|-------:|----------:|
| &#39;DIFF-01 serialize&#39;   | Headerless           |  2.634 μs | 0.1058 μs | 0.0990 μs |  2.609 μs |  2.764 μs | 379,679.5 | 0.1945 |      - |    1.2 KB |
| &#39;DIFF-01 deserialize&#39; | Headerless           |  3.131 μs | 0.1035 μs | 0.0968 μs |  3.114 μs |  3.300 μs | 319,432.9 | 0.6561 | 0.0076 |   4.03 KB |
| &#39;DIFF-01 serialize&#39;   | MinimalHeader        |  2.806 μs | 0.0876 μs | 0.0820 μs |  2.777 μs |  2.952 μs | 356,353.8 | 0.2174 |      - |   1.34 KB |
| &#39;DIFF-01 deserialize&#39; | MinimalHeader        |  3.375 μs | 0.1139 μs | 0.1065 μs |  3.342 μs |  3.529 μs | 296,329.3 | 0.6676 | 0.0076 |    4.1 KB |
| &#39;DIFF-01 serialize&#39;   | Encrypted            |  4.176 μs | 0.1450 μs | 0.1357 μs |  4.103 μs |  4.384 μs | 239,483.3 | 0.2441 |      - |   1.52 KB |
| &#39;DIFF-01 deserialize&#39; | Encrypted            |  4.891 μs | 0.1548 μs | 0.1448 μs |  4.829 μs |  5.099 μs | 204,461.6 | 0.7248 | 0.0076 |   4.46 KB |
| &#39;DIFF-01 serialize&#39;   | EncryptedWithKeyId   |  4.185 μs | 0.1260 μs | 0.1179 μs |  4.139 μs |  4.350 μs | 238,947.1 | 0.2518 |      - |   1.55 KB |
| &#39;DIFF-01 deserialize&#39; | EncryptedWithKeyId   |  4.775 μs | 0.1269 μs | 0.1187 μs |  4.740 μs |  4.942 μs | 209,441.5 | 0.7324 | 0.0076 |   4.52 KB |
| &#39;DIFF-01 serialize&#39;   | Protected            | 27.549 μs | 0.6631 μs | 0.6203 μs | 27.329 μs | 28.632 μs |  36,299.3 | 0.2747 |      - |   1.79 KB |
| &#39;DIFF-01 deserialize&#39; | Protected            | 11.576 μs | 0.3370 μs | 0.3152 μs | 11.568 μs | 12.113 μs |  86,385.1 | 0.8545 |      - |   5.24 KB |
| &#39;DIFF-01 serialize&#39;   | ProtectedCustomNames | 27.816 μs | 0.6373 μs | 0.5961 μs | 27.827 μs | 28.850 μs |  35,950.8 | 0.2747 |      - |   1.84 KB |
| &#39;DIFF-01 deserialize&#39; | ProtectedCustomNames | 11.705 μs | 0.1660 μs | 0.1472 μs | 11.639 μs | 11.947 μs |  85,432.5 | 0.9613 |      - |   5.95 KB |
