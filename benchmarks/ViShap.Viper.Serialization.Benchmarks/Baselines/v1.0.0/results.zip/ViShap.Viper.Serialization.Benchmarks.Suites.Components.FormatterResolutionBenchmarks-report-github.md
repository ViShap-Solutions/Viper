```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                              | Mean      | Error     | StdDev    | Median    | P95       | Op/s            | Allocated |
|------------------------------------ |----------:|----------:|----------:|----------:|----------:|----------------:|----------:|
| &#39;MICRO-05 resolve claimed sequence&#39; | 0.2308 ns | 0.0002 ns | 0.0002 ns | 0.2308 ns | 0.2311 ns | 4,332,263,532.5 |         - |
| &#39;MICRO-05 resolve claimed map&#39;      | 0.2300 ns | 0.0001 ns | 0.0001 ns | 0.2300 ns | 0.2302 ns | 4,347,237,609.2 |         - |
| &#39;MICRO-05 resolve member-encoded&#39;   | 0.2300 ns | 0.0003 ns | 0.0003 ns | 0.2299 ns | 0.2305 ns | 4,347,564,268.7 |         - |
