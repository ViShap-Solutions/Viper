```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                     | Mean         | Error      | StdDev     | Median       | P95          | Op/s          | Gen0   | Gen1   | Allocated |
|--------------------------- |-------------:|-----------:|-----------:|-------------:|-------------:|--------------:|-------:|-------:|----------:|
| &#39;MICRO-06 scalar write&#39;    |     5.444 ns |  0.1879 ns |  0.1757 ns |     5.389 ns |     5.686 ns | 183,690,855.4 |      - |      - |         - |
| &#39;MICRO-06 scalar read&#39;     |     8.509 ns |  0.2433 ns |  0.2275 ns |     8.415 ns |     8.833 ns | 117,520,950.6 |      - |      - |         - |
| &#39;MICRO-06 sequence write&#39;  |   181.125 ns |  4.6731 ns |  4.3712 ns |   181.376 ns |   187.375 ns |   5,521,062.5 |      - |      - |         - |
| &#39;MICRO-06 sequence read&#39;   |   449.487 ns |  5.2231 ns |  4.3615 ns |   448.598 ns |   457.674 ns |   2,224,756.8 | 0.0725 |      - |     456 B |
| &#39;MICRO-06 map write&#39;       |   470.920 ns | 12.4149 ns | 11.6129 ns |   471.801 ns |   485.939 ns |   2,123,504.3 |      - |      - |         - |
| &#39;MICRO-06 map read&#39;        | 1,208.665 ns | 41.6414 ns | 38.9514 ns | 1,215.626 ns | 1,264.709 ns |     827,358.8 | 0.4978 | 0.0057 |    3128 B |
| &#39;MICRO-06 composite write&#39; |    49.941 ns |  1.2584 ns |  1.1771 ns |    50.107 ns |    51.644 ns |  20,023,815.9 |      - |      - |         - |
| &#39;MICRO-06 composite read&#39;  |    66.611 ns |  1.4833 ns |  1.3875 ns |    66.141 ns |    68.670 ns |  15,012,518.3 | 0.0063 |      - |      40 B |
