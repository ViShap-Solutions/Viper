```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                  | AllFields | Mean      | Error     | StdDev    | Median    | P95       | Op/s         | Gen0   | Allocated |
|------------------------ |---------- |----------:|----------:|----------:|----------:|----------:|-------------:|-------:|----------:|
| &#39;MICRO-08 write header&#39; | False     |  31.23 ns |  1.139 ns |  1.066 ns |  30.97 ns |  32.65 ns | 32,018,224.9 |      - |         - |
| &#39;MICRO-08 parse header&#39; | False     |  32.99 ns |  0.949 ns |  0.887 ns |  32.93 ns |  34.39 ns | 30,316,503.3 |      - |         - |
| &#39;MICRO-08 write header&#39; | True      | 157.67 ns |  4.161 ns |  3.892 ns | 158.29 ns | 164.50 ns |  6,342,388.8 |      - |         - |
| &#39;MICRO-08 parse header&#39; | True      | 470.99 ns | 11.882 ns | 11.114 ns | 471.23 ns | 485.57 ns |  2,123,173.7 | 0.2193 |    1376 B |
