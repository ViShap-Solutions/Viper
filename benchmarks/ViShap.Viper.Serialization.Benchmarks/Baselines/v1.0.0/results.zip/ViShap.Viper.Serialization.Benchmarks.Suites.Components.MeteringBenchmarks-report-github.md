```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                    | Mean      | Error     | StdDev    | Median    | P95       | Op/s          | Gen0   | Allocated |
|-------------------------- |----------:|----------:|----------:|----------:|----------:|--------------:|-------:|----------:|
| &#39;MICRO-09 bare write&#39;     |  5.533 ns | 0.1373 ns | 0.1284 ns |  5.526 ns |  5.709 ns | 180,744,860.3 |      - |         - |
| &#39;MICRO-09 metered write&#39;  | 13.272 ns | 0.3675 ns | 0.3437 ns | 13.140 ns | 13.752 ns |  75,346,914.4 | 0.0002 |       1 B |
| &#39;MICRO-09 bare read&#39;      |  3.158 ns | 0.0513 ns | 0.0480 ns |  3.140 ns |  3.231 ns | 316,683,799.4 |      - |         - |
| &#39;MICRO-09 metered read&#39;   |  5.445 ns | 0.1532 ns | 0.1433 ns |  5.463 ns |  5.672 ns | 183,657,609.6 |      - |         - |
| &#39;MICRO-09 window read&#39;    |  5.675 ns | 0.1746 ns | 0.1633 ns |  5.708 ns |  5.867 ns | 176,213,947.6 |      - |         - |
| &#39;MICRO-09 window skip&#39;    |  1.070 ns | 0.0390 ns | 0.0364 ns |  1.077 ns |  1.126 ns | 934,426,474.1 |      - |         - |
| &#39;MICRO-09 copy to stream&#39; |  4.995 ns | 0.0030 ns | 0.0027 ns |  4.994 ns |  5.000 ns | 200,215,354.6 |      - |         - |
