```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                               | SharedPercent | Mean       | Error     | StdDev    | Median     | P95        | Op/s              | Allocated |
|------------------------------------- |-------------- |-----------:|----------:|----------:|-----------:|-----------:|------------------:|----------:|
| &#39;MICRO-07 write lookup and register&#39; | 0             | 15.9233 ns | 0.4257 ns | 0.3982 ns | 15.9497 ns | 16.4822 ns |      62,801,100.8 |         - |
| &#39;MICRO-07 read register and resolve&#39; | 0             |  7.8068 ns | 0.2655 ns | 0.2484 ns |  7.8047 ns |  8.1630 ns |     128,093,458.2 |         - |
| &#39;MICRO-07 table rent and return&#39;     | 0             |  0.0053 ns | 0.0001 ns | 0.0001 ns |  0.0053 ns |  0.0054 ns | 189,337,713,764.1 |         - |
| &#39;MICRO-07 write lookup and register&#39; | 10            | 14.5958 ns | 0.4240 ns | 0.3966 ns | 14.3490 ns | 15.3173 ns |      68,513,058.2 |         - |
| &#39;MICRO-07 read register and resolve&#39; | 10            |  6.9445 ns | 0.1804 ns | 0.1687 ns |  6.8936 ns |  7.3035 ns |     143,999,644.9 |         - |
| &#39;MICRO-07 table rent and return&#39;     | 10            |  0.0055 ns | 0.0003 ns | 0.0003 ns |  0.0057 ns |  0.0058 ns | 182,855,033,639.3 |         - |
| &#39;MICRO-07 write lookup and register&#39; | 50            |  8.4552 ns | 0.2969 ns | 0.2318 ns |  8.4464 ns |  8.7157 ns |     118,269,905.6 |         - |
| &#39;MICRO-07 read register and resolve&#39; | 50            |  4.7265 ns | 0.1230 ns | 0.1150 ns |  4.7145 ns |  4.9151 ns |     211,573,128.0 |         - |
| &#39;MICRO-07 table rent and return&#39;     | 50            |  0.0061 ns | 0.0003 ns | 0.0002 ns |  0.0062 ns |  0.0064 ns | 163,440,114,392.0 |         - |
| &#39;MICRO-07 write lookup and register&#39; | 90            |  4.9720 ns | 0.1464 ns | 0.1369 ns |  4.9156 ns |  5.2413 ns |     201,124,325.2 |         - |
| &#39;MICRO-07 read register and resolve&#39; | 90            |  2.6453 ns | 0.0601 ns | 0.0562 ns |  2.6387 ns |  2.7233 ns |     378,028,962.4 |         - |
| &#39;MICRO-07 table rent and return&#39;     | 90            |  0.0055 ns | 0.0002 ns | 0.0002 ns |  0.0055 ns |  0.0058 ns | 182,475,265,722.0 |         - |
