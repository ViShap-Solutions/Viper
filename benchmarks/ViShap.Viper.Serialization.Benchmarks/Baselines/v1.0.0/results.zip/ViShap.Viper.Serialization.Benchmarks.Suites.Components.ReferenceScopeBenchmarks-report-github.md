```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                                | Mean     | Error     | StdDev    | Median   | P95      | Op/s          | Allocated |
|-------------------------------------- |---------:|----------:|----------:|---------:|---------:|--------------:|----------:|
| &#39;MICRO-07 write scope enter and exit&#39; | 2.597 ns | 0.0523 ns | 0.0489 ns | 2.573 ns | 2.675 ns | 385,018,475.4 |         - |
| &#39;MICRO-07 read scope enter and exit&#39;  | 2.586 ns | 0.0530 ns | 0.0496 ns | 2.560 ns | 2.649 ns | 386,749,387.8 |         - |
