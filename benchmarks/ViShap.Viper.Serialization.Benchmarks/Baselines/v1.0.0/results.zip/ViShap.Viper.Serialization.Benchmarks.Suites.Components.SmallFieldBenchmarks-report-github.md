```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                              | Mean     | Error   | StdDev  | Median   | P95      | Op/s        | Gen0   | Allocated |
|------------------------------------ |---------:|--------:|--------:|---------:|---------:|------------:|-------:|----------:|
| &#39;MICRO-17 write small-field record&#39; | 288.0 ns | 7.09 ns | 6.63 ns | 284.7 ns | 301.3 ns | 3,472,159.6 |      - |         - |
| &#39;MICRO-17 read small-field record&#39;  | 274.4 ns | 8.56 ns | 8.00 ns | 276.2 ns | 282.5 ns | 3,644,326.5 | 0.0086 |      56 B |
