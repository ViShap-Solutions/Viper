```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method           | Primitive       | Mean       | Error     | StdDev    | Median     | P95        | Op/s            | Allocated |
|----------------- |---------------- |-----------:|----------:|----------:|-----------:|-----------:|----------------:|----------:|
| &#39;MICRO-01 write&#39; | Byte            |  0.6851 ns | 0.0157 ns | 0.0147 ns |  0.6844 ns |  0.7035 ns | 1,459,661,039.1 |         - |
| &#39;MICRO-01 read&#39;  | Byte            |  0.9654 ns | 0.0231 ns | 0.0216 ns |  0.9682 ns |  0.9953 ns | 1,035,871,410.1 |         - |
| &#39;MICRO-01 write&#39; | Int16           |  0.9685 ns | 0.0227 ns | 0.0212 ns |  0.9629 ns |  0.9968 ns | 1,032,575,716.1 |         - |
| &#39;MICRO-01 read&#39;  | Int16           |  2.1499 ns | 0.0790 ns | 0.0739 ns |  2.1697 ns |  2.2446 ns |   465,136,201.3 |         - |
| &#39;MICRO-01 write&#39; | Int32           |  0.9993 ns | 0.0338 ns | 0.0316 ns |  1.0087 ns |  1.0432 ns | 1,000,722,504.0 |         - |
| &#39;MICRO-01 read&#39;  | Int32           |  2.3033 ns | 0.0936 ns | 0.0876 ns |  2.2881 ns |  2.4475 ns |   434,162,729.3 |         - |
| &#39;MICRO-01 write&#39; | Int64           |  0.9403 ns | 0.0264 ns | 0.0234 ns |  0.9400 ns |  0.9791 ns | 1,063,436,430.3 |         - |
| &#39;MICRO-01 read&#39;  | Int64           |  2.1345 ns | 0.0766 ns | 0.0716 ns |  2.1084 ns |  2.2466 ns |   468,488,641.6 |         - |
| &#39;MICRO-01 write&#39; | Double          |  1.1942 ns | 0.0225 ns | 0.0210 ns |  1.1956 ns |  1.2224 ns |   837,354,009.4 |         - |
| &#39;MICRO-01 read&#39;  | Double          |  2.5281 ns | 0.0850 ns | 0.0795 ns |  2.5312 ns |  2.6517 ns |   395,549,461.0 |         - |
| &#39;MICRO-01 write&#39; | Decimal         |  3.7798 ns | 0.1341 ns | 0.1254 ns |  3.8055 ns |  3.9555 ns |   264,560,944.1 |         - |
| &#39;MICRO-01 read&#39;  | Decimal         | 35.2278 ns | 0.6578 ns | 0.6153 ns | 34.9381 ns | 36.1954 ns |    28,386,633.9 |         - |
| &#39;MICRO-01 write&#39; | VarIntOneByte   |  0.6555 ns | 0.0190 ns | 0.0178 ns |  0.6590 ns |  0.6793 ns | 1,525,519,472.7 |         - |
| &#39;MICRO-01 read&#39;  | VarIntOneByte   |  2.9452 ns | 0.0889 ns | 0.0831 ns |  2.9050 ns |  3.0551 ns |   339,530,107.2 |         - |
| &#39;MICRO-01 write&#39; | VarIntFiveBytes |  5.0132 ns | 0.1655 ns | 0.1467 ns |  5.0015 ns |  5.2497 ns |   199,472,375.6 |         - |
| &#39;MICRO-01 read&#39;  | VarIntFiveBytes |  7.8550 ns | 0.3051 ns | 0.2854 ns |  7.7775 ns |  8.3330 ns |   127,308,021.2 |         - |
