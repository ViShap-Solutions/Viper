```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                         | Threads | Data                 | Mean        | Error       | StdDev      | Median      | P95         | Op/s     | Gen0       | Gen1      | Gen2   | Allocated   |
|------------------------------- |-------- |--------------------- |------------:|------------:|------------:|------------:|------------:|---------:|-----------:|----------:|-------:|------------:|
| &#39;PAR serialize on N threads&#39;   | 1       | DATA-01 TinyFlat     |    170.2 μs |     0.29 μs |     0.26 μs |    170.3 μs |    170.6 μs | 5,874.29 |    13.1836 |         - |      - |    80.55 KB |
| &#39;PAR deserialize on N threads&#39; | 1       | DATA-01 TinyFlat     |    146.5 μs |     2.77 μs |     2.46 μs |    146.1 μs |    150.0 μs | 6,823.92 |     7.8125 |    0.2441 |      - |    44.48 KB |
| &#39;PAR serialize on N threads&#39;   | 1       | DATA-02 MediumObject |    743.2 μs |    37.98 μs |    35.52 μs |    729.7 μs |    793.6 μs | 1,345.60 |    39.0625 |         - |      - |   270.65 KB |
| &#39;PAR deserialize on N threads&#39; | 1       | DATA-02 MediumObject |    866.2 μs |    18.89 μs |    17.67 μs |    867.6 μs |    895.9 μs | 1,154.49 |   132.8125 |         - |      - |   821.05 KB |
| &#39;PAR serialize on N threads&#39;   | 1       | DATA-(...)Small [24] |  8,793.9 μs |   161.98 μs |   143.59 μs |  8,789.9 μs |  9,034.4 μs |   113.72 |   703.1250 |   78.1250 |      - |  4336.67 KB |
| &#39;PAR deserialize on N threads&#39; | 1       | DATA-(...)Small [24] | 11,953.2 μs |   162.79 μs |   135.94 μs | 11,998.8 μs | 12,104.0 μs |    83.66 |  1218.7500 |  125.0000 |      - |  7494.48 KB |
| &#39;PAR serialize on N threads&#39;   | 2       | DATA-01 TinyFlat     |    237.0 μs |     4.50 μs |     3.76 μs |    236.0 μs |    242.4 μs | 4,220.02 |    26.3672 |    0.9766 |      - |   160.81 KB |
| &#39;PAR deserialize on N threads&#39; | 2       | DATA-01 TinyFlat     |    230.0 μs |    11.23 μs |    10.50 μs |    227.3 μs |    247.6 μs | 4,347.08 |    15.8691 |    0.4883 | 0.2441 |    88.67 KB |
| &#39;PAR serialize on N threads&#39;   | 2       | DATA-02 MediumObject |    875.5 μs |    64.58 μs |    60.41 μs |    844.9 μs |    970.9 μs | 1,142.18 |    85.9375 |         - |      - |   540.97 KB |
| &#39;PAR deserialize on N threads&#39; | 2       | DATA-02 MediumObject |  1,070.6 μs |    53.15 μs |    47.12 μs |  1,062.1 μs |  1,157.0 μs |   934.04 |   269.5313 |    7.8125 |      - |   1641.8 KB |
| &#39;PAR serialize on N threads&#39;   | 2       | DATA-(...)Small [24] | 11,918.4 μs | 1,993.60 μs | 1,864.81 μs | 11,032.7 μs | 15,196.4 μs |    83.90 |  1750.0000 |  250.0000 |      - |  8673.11 KB |
| &#39;PAR deserialize on N threads&#39; | 2       | DATA-(...)Small [24] | 13,591.4 μs |   547.26 μs |   511.91 μs | 13,552.2 μs | 14,293.6 μs |    73.58 |  2468.7500 |  453.1250 |      - | 14988.67 KB |
| &#39;PAR serialize on N threads&#39;   | 4       | DATA-01 TinyFlat     |    427.5 μs |    23.20 μs |    21.70 μs |    430.8 μs |    455.2 μs | 2,339.05 |    54.6875 |    1.9531 |      - |   321.33 KB |
| &#39;PAR deserialize on N threads&#39; | 4       | DATA-01 TinyFlat     |    338.2 μs |     4.78 μs |     4.24 μs |    336.4 μs |    346.2 μs | 2,956.44 |    31.2500 |         - |      - |   177.05 KB |
| &#39;PAR serialize on N threads&#39;   | 4       | DATA-02 MediumObject |  1,065.4 μs |    21.65 μs |    20.25 μs |  1,063.6 μs |  1,103.7 μs |   938.63 |   179.6875 |    7.8125 |      - |  1081.59 KB |
| &#39;PAR deserialize on N threads&#39; | 4       | DATA-02 MediumObject |  1,278.3 μs |    59.97 μs |    56.09 μs |  1,263.7 μs |  1,378.7 μs |   782.30 |   531.2500 |   15.6250 |      - |   3283.3 KB |
| &#39;PAR serialize on N threads&#39;   | 4       | DATA-(...)Small [24] | 11,675.5 μs |   115.06 μs |   107.63 μs | 11,683.1 μs | 11,844.7 μs |    85.65 |  3781.2500 |   15.6250 |      - | 17345.92 KB |
| &#39;PAR deserialize on N threads&#39; | 4       | DATA-(...)Small [24] | 14,919.8 μs |   120.90 μs |   113.09 μs | 14,879.4 μs | 15,080.4 μs |    67.03 |  4953.1250 | 1281.2500 |      - | 29977.05 KB |
| &#39;PAR serialize on N threads&#39;   | 8       | DATA-01 TinyFlat     |    665.6 μs |     9.43 μs |     7.87 μs |    662.3 μs |    678.1 μs | 1,502.35 |   111.3281 |         - |      - |   642.28 KB |
| &#39;PAR deserialize on N threads&#39; | 8       | DATA-01 TinyFlat     |    595.0 μs |     4.27 μs |     4.00 μs |    594.9 μs |    601.2 μs | 1,680.77 |    62.5000 |    1.9531 | 0.9766 |    353.8 KB |
| &#39;PAR serialize on N threads&#39;   | 8       | DATA-02 MediumObject |  1,953.3 μs |    36.64 μs |    32.48 μs |  1,954.2 μs |  1,999.6 μs |   511.94 |   359.3750 |   15.6250 |      - |  2162.97 KB |
| &#39;PAR deserialize on N threads&#39; | 8       | DATA-02 MediumObject |  2,364.0 μs |    81.66 μs |    76.38 μs |  2,318.9 μs |  2,481.1 μs |   423.01 |  1078.1250 |   78.1250 |      - |   6566.3 KB |
| &#39;PAR serialize on N threads&#39;   | 8       | DATA-(...)Small [24] | 22,365.9 μs | 1,963.93 μs | 1,837.06 μs | 22,837.5 μs | 24,780.5 μs |    44.71 |  7333.3333 |  333.3333 |      - | 34691.22 KB |
| &#39;PAR deserialize on N threads&#39; | 8       | DATA-(...)Small [24] | 25,910.7 μs |   676.76 μs |   633.04 μs | 25,660.8 μs | 26,903.5 μs |    38.59 |  9666.6667 | 3000.0000 |      - |  59953.8 KB |
| &#39;PAR serialize on N threads&#39;   | 12      | DATA-01 TinyFlat     |    930.9 μs |    14.72 μs |    13.77 μs |    930.5 μs |    951.0 μs | 1,074.22 |   164.0625 |    7.8125 |      - |    963.1 KB |
| &#39;PAR deserialize on N threads&#39; | 12      | DATA-01 TinyFlat     |    896.4 μs |     9.53 μs |     8.92 μs |    896.5 μs |    907.9 μs | 1,115.57 |    93.7500 |         - |      - |   530.55 KB |
| &#39;PAR serialize on N threads&#39;   | 12      | DATA-02 MediumObject |  2,768.8 μs |   137.65 μs |   122.02 μs |  2,703.2 μs |  3,011.7 μs |   361.16 |   531.2500 |   31.2500 |      - |  3244.38 KB |
| &#39;PAR deserialize on N threads&#39; | 12      | DATA-02 MediumObject |  3,285.5 μs |    60.99 μs |    50.93 μs |  3,272.1 μs |  3,358.1 μs |   304.37 |  1625.0000 |  156.2500 |      - |   9849.3 KB |
| &#39;PAR serialize on N threads&#39;   | 12      | DATA-(...)Small [24] | 31,101.2 μs |   612.73 μs |   543.17 μs | 30,947.9 μs | 32,042.9 μs |    32.15 | 11333.3333 |  666.6667 |      - | 52036.68 KB |
| &#39;PAR deserialize on N threads&#39; | 12      | DATA-(...)Small [24] | 39,018.8 μs |   124.99 μs |   104.37 μs | 39,017.3 μs | 39,168.1 μs |    25.63 | 14846.1538 | 5384.6154 |      - | 89930.55 KB |
