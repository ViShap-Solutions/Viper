```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                      | Profile         | Data             | Mean       | Error     | StdDev    | Median     | P95        | Op/s        | Gen0   | Allocated |
|---------------------------- |---------------- |----------------- |-----------:|----------:|----------:|-----------:|-----------:|------------:|-------:|----------:|
| &#39;WL-20 frames ← PipeReader&#39; | Default         | DATA-01 TinyFlat |   536.0 ns |  16.50 ns |  15.44 ns |   532.5 ns |   564.3 ns | 1,865,748.3 | 0.0352 |     224 B |
| &#39;WL-20 frames ← Stream&#39;     | Default         | DATA-01 TinyFlat |   615.8 ns |  23.16 ns |  21.66 ns |   605.4 ns |   647.6 ns | 1,624,034.2 | 0.0352 |     224 B |
| &#39;WL-20 frames ← PipeReader&#39; | ProtectedBrotli | DATA-01 TinyFlat | 2,864.7 ns |  72.17 ns |  67.51 ns | 2,851.0 ns | 2,982.9 ns |   349,079.0 | 0.2773 |    1761 B |
| &#39;WL-20 frames ← Stream&#39;     | ProtectedBrotli | DATA-01 TinyFlat | 3,259.8 ns | 110.78 ns | 103.63 ns | 3,201.6 ns | 3,408.4 ns |   306,766.9 | 0.2773 |    1761 B |
