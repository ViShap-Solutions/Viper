```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method              | Data                 | Mean     | Error     | StdDev    | Median   | P95      | Op/s          | Allocated |
|-------------------- |--------------------- |---------:|----------:|----------:|---------:|---------:|--------------:|----------:|
| &#39;floor serialize&#39;   | DATA-01 TinyFlat     | 3.973 ns | 0.2631 ns | 0.2461 ns | 3.995 ns | 4.311 ns | 251,721,551.1 |         - |
| &#39;floor deserialize&#39; | DATA-01 TinyFlat     | 5.293 ns | 0.2765 ns | 0.2586 ns | 5.115 ns | 5.667 ns | 188,926,088.1 |         - |
| &#39;floor serialize&#39;   | DATA-02 MediumObject | 4.028 ns | 0.2627 ns | 0.2458 ns | 3.881 ns | 4.373 ns | 248,282,850.2 |         - |
| &#39;floor deserialize&#39; | DATA-02 MediumObject | 4.058 ns | 0.2553 ns | 0.2388 ns | 3.914 ns | 4.396 ns | 246,440,433.7 |         - |
| &#39;floor serialize&#39;   | DATA-(...)Small [24] | 3.690 ns | 0.2452 ns | 0.2293 ns | 3.730 ns | 3.949 ns | 271,036,813.1 |         - |
| &#39;floor deserialize&#39; | DATA-(...)Small [24] | 4.990 ns | 0.2918 ns | 0.2730 ns | 4.789 ns | 5.348 ns | 200,400,467.3 |         - |
| &#39;floor serialize&#39;   | DATA-(...)Large [24] | 3.602 ns | 0.2457 ns | 0.2298 ns | 3.470 ns | 3.993 ns | 277,625,052.5 |         - |
| &#39;floor deserialize&#39; | DATA-(...)Large [24] | 4.059 ns | 0.2574 ns | 0.2408 ns | 3.894 ns | 4.413 ns | 246,370,832.4 |         - |
| &#39;floor serialize&#39;   | DATA-(...)Heavy [23] | 3.649 ns | 0.2187 ns | 0.2045 ns | 3.541 ns | 3.936 ns | 274,015,891.9 |         - |
| &#39;floor deserialize&#39; | DATA-(...)Heavy [23] | 3.957 ns | 0.2402 ns | 0.2247 ns | 3.830 ns | 4.337 ns | 252,711,275.2 |         - |
| &#39;floor serialize&#39;   | DATA-(...)Heavy [28] | 3.592 ns | 0.2334 ns | 0.2183 ns | 3.608 ns | 3.896 ns | 278,405,879.6 |         - |
| &#39;floor deserialize&#39; | DATA-(...)Heavy [28] | 5.298 ns | 0.2929 ns | 0.2740 ns | 5.475 ns | 5.609 ns | 188,756,847.0 |         - |
