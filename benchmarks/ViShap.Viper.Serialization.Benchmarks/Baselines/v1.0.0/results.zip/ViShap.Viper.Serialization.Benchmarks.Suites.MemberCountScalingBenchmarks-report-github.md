```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                 | Members | Keyed | Mean        | Error     | StdDev    | Median      | P95         | Op/s        | Gen0   | Gen1   | Allocated |
|----------------------- |-------- |------ |------------:|----------:|----------:|------------:|------------:|------------:|-------:|-------:|----------:|
| &#39;SCALE-04 serialize&#39;   | 5       | False |    315.7 ns |   9.75 ns |   9.12 ns |    315.7 ns |    329.4 ns | 3,167,792.6 | 0.0572 |      - |     360 B |
| &#39;SCALE-04 deserialize&#39; | 5       | False |    227.7 ns |   6.76 ns |   6.33 ns |    224.8 ns |    239.2 ns | 4,391,137.3 | 0.0317 |      - |     200 B |
| &#39;SCALE-04 serialize&#39;   | 5       | True  |    401.4 ns |  11.90 ns |  11.13 ns |    399.9 ns |    420.7 ns | 2,491,070.8 | 0.0610 |      - |     384 B |
| &#39;SCALE-04 deserialize&#39; | 5       | True  |    388.5 ns |  10.42 ns |   9.75 ns |    391.3 ns |    399.6 ns | 2,573,710.9 | 0.0315 |      - |     200 B |
| &#39;SCALE-04 serialize&#39;   | 20      | False |    489.2 ns |  16.99 ns |  15.89 ns |    490.8 ns |    506.5 ns | 2,044,331.3 | 0.0777 |      - |     488 B |
| &#39;SCALE-04 deserialize&#39; | 20      | False |    471.3 ns |  17.74 ns |  16.60 ns |    462.4 ns |    493.6 ns | 2,121,708.4 | 0.0634 |      - |     400 B |
| &#39;SCALE-04 serialize&#39;   | 20      | True  |    904.3 ns |  27.53 ns |  25.75 ns |    890.3 ns |    945.5 ns | 1,105,803.3 | 0.0925 |      - |     584 B |
| &#39;SCALE-04 deserialize&#39; | 20      | True  |    907.2 ns |  11.97 ns |   9.35 ns |    904.8 ns |    922.0 ns | 1,102,284.3 | 0.0629 |      - |     400 B |
| &#39;SCALE-04 serialize&#39;   | 50      | False |    867.8 ns |  29.31 ns |  27.42 ns |    864.7 ns |    906.9 ns | 1,152,304.2 | 0.1230 |      - |     776 B |
| &#39;SCALE-04 deserialize&#39; | 50      | False |    952.3 ns |  31.46 ns |  29.42 ns |    956.3 ns |    995.2 ns | 1,050,112.5 | 0.1373 |      - |     864 B |
| &#39;SCALE-04 serialize&#39;   | 50      | True  |  1,961.9 ns |  61.97 ns |  57.97 ns |  1,969.6 ns |  2,054.0 ns |   509,717.3 | 0.1755 |      - |    1120 B |
| &#39;SCALE-04 deserialize&#39; | 50      | True  |  2,247.6 ns |  64.81 ns |  60.62 ns |  2,254.8 ns |  2,326.2 ns |   444,918.5 | 0.1373 |      - |     864 B |
| &#39;SCALE-04 serialize&#39;   | 100     | False |  1,525.6 ns |  47.15 ns |  44.10 ns |  1,511.4 ns |  1,587.5 ns |   655,468.0 | 0.2136 |      - |    1352 B |
| &#39;SCALE-04 deserialize&#39; | 100     | False |  1,742.7 ns |  52.60 ns |  49.20 ns |  1,725.2 ns |  1,829.0 ns |   573,821.3 | 0.2632 |      - |    1656 B |
| &#39;SCALE-04 serialize&#39;   | 100     | True  |  3,694.7 ns | 119.19 ns | 111.49 ns |  3,637.1 ns |  3,867.6 ns |   270,655.6 | 0.2937 |      - |    1856 B |
| &#39;SCALE-04 deserialize&#39; | 100     | True  |  4,418.2 ns | 158.54 ns | 148.30 ns |  4,355.5 ns |  4,627.5 ns |   226,336.6 | 0.2594 |      - |    1656 B |
| &#39;SCALE-04 serialize&#39;   | 200     | False |  2,877.9 ns | 101.56 ns |  95.00 ns |  2,887.5 ns |  3,010.4 ns |   347,480.9 | 0.3700 |      - |    2336 B |
| &#39;SCALE-04 deserialize&#39; | 200     | False |  3,456.8 ns | 110.18 ns | 103.06 ns |  3,453.7 ns |  3,587.0 ns |   289,281.4 | 0.5112 | 0.0038 |    3216 B |
| &#39;SCALE-04 serialize&#39;   | 200     | True  |  9,360.8 ns | 260.43 ns | 243.61 ns |  9,254.7 ns |  9,703.8 ns |   106,828.9 | 0.5341 |      - |    3408 B |
| &#39;SCALE-04 deserialize&#39; | 200     | True  | 10,805.9 ns | 285.95 ns | 267.48 ns | 10,768.6 ns | 11,217.1 ns |    92,542.1 | 0.5035 |      - |    3216 B |
