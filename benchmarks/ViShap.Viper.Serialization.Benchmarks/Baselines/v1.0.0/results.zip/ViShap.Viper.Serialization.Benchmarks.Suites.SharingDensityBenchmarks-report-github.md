```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9974)
11th Gen Intel Core i5-11400H 2.70GHz (Max: 2.69GHz), 1 CPU, 12 logical and 6 physical cores
.NET SDK 10.0.404
  [Host]      : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4
  Publication : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=Publication  IterationCount=15  LaunchCount=1  
WarmupCount=5  

```
| Method                 | SharedPercent | Profile            | Mean      | Error     | StdDev    | Median    | P95       | Op/s     | Gen0    | Gen1    | Allocated |
|----------------------- |-------------- |------------------- |----------:|----------:|----------:|----------:|----------:|---------:|--------:|--------:|----------:|
| &#39;SCALE-07 serialize&#39;   | 0             | Default            | 228.28 μs |  6.458 μs |  5.725 μs | 226.37 μs | 239.69 μs |  4,380.6 |  8.5449 |       - |  53.16 KB |
| &#39;SCALE-07 deserialize&#39; | 0             | Default            | 325.08 μs | 14.049 μs | 13.142 μs | 317.92 μs | 344.07 μs |  3,076.2 | 53.7109 | 17.5781 | 329.68 KB |
| &#39;SCALE-07 serialize&#39;   | 0             | PreserveReferences | 311.04 μs | 14.170 μs | 13.255 μs | 302.18 μs | 330.61 μs |  3,215.0 |  9.2773 |       - |  58.96 KB |
| &#39;SCALE-07 deserialize&#39; | 0             | PreserveReferences | 382.86 μs | 16.771 μs | 15.688 μs | 377.36 μs | 407.95 μs |  2,611.9 | 53.7109 | 17.5781 | 329.68 KB |
| &#39;SCALE-07 serialize&#39;   | 10            | Default            | 217.48 μs |  6.288 μs |  5.574 μs | 215.30 μs | 228.68 μs |  4,598.2 |  8.3008 |       - |  52.17 KB |
| &#39;SCALE-07 deserialize&#39; | 10            | Default            | 312.57 μs | 10.068 μs |  9.417 μs | 314.59 μs | 324.99 μs |  3,199.2 | 53.2227 | 18.0664 | 328.52 KB |
| &#39;SCALE-07 serialize&#39;   | 10            | PreserveReferences | 263.93 μs |  8.541 μs |  7.989 μs | 265.69 μs | 273.44 μs |  3,788.9 |  8.3008 |       - |  53.48 KB |
| &#39;SCALE-07 deserialize&#39; | 10            | PreserveReferences | 337.22 μs | 10.729 μs | 10.036 μs | 341.27 μs | 349.74 μs |  2,965.4 | 48.3398 | 16.1133 | 298.84 KB |
| &#39;SCALE-07 serialize&#39;   | 50            | Default            | 221.13 μs |  8.297 μs |  7.761 μs | 214.94 μs | 230.41 μs |  4,522.3 |  7.5684 |       - |  47.48 KB |
| &#39;SCALE-07 deserialize&#39; | 50            | Default            | 290.07 μs |  9.297 μs |  8.696 μs | 290.32 μs | 300.71 μs |  3,447.5 | 52.2461 | 17.0898 | 321.52 KB |
| &#39;SCALE-07 serialize&#39;   | 50            | PreserveReferences | 166.81 μs |  5.160 μs |  4.827 μs | 167.52 μs | 173.28 μs |  5,994.9 |  4.8828 |       - |  31.07 KB |
| &#39;SCALE-07 deserialize&#39; | 50            | PreserveReferences | 224.91 μs |  7.845 μs |  7.338 μs | 222.38 μs | 236.96 μs |  4,446.2 | 28.3203 |  7.3242 | 174.72 KB |
| &#39;SCALE-07 serialize&#39;   | 90            | Default            | 203.62 μs |  6.676 μs |  6.245 μs | 200.20 μs | 213.93 μs |  4,911.0 |  6.8359 |       - |   42.7 KB |
| &#39;SCALE-07 deserialize&#39; | 90            | Default            | 271.12 μs |  8.320 μs |  7.783 μs | 266.63 μs | 283.47 μs |  3,688.4 | 51.2695 | 17.0898 |  314.3 KB |
| &#39;SCALE-07 serialize&#39;   | 90            | PreserveReferences |  36.77 μs |  1.199 μs |  1.122 μs |  36.22 μs |  38.62 μs | 27,198.9 |  1.2817 |       - |   7.91 KB |
| &#39;SCALE-07 deserialize&#39; | 90            | PreserveReferences |  74.55 μs |  2.307 μs |  2.158 μs |  75.35 μs |  77.08 μs | 13,413.2 |  7.5684 |  0.8545 |  46.97 KB |
